"""Registered server-owned effect adapters for this domain."""
from __future__ import annotations

from execution_adapter_contract import ExecutionContext, ExecutionGatewayError
from typing import Any
from execution_request import ExecutionRequest


class FilesystemEffectAdapter:
    """Gateway-owned adapter for one scoped workspace file write."""

    effect_ids = frozenset({"filesystem.write"})

    @staticmethod
    def revalidate_world_state(request: ExecutionRequest, context: ExecutionContext) -> None:
        """Recheck BER create/modify preconditions at the Gateway boundary."""
        arguments = request.arguments if isinstance(request.arguments, dict) else {}
        if "expected_exists" not in arguments:
            return  # Preserve the established BAGO Full request contract.
        manager = context.manager
        if manager is None:
            raise ExecutionGatewayError(
                "Filesystem write requires SessionManager context",
                code="execution_context_manager_required",
            )
        from filesystem_effects import FilesystemEffectError, _resolve_target

        try:
            target, _, _ = _resolve_target(manager, str(request.target.get("path") or ""))
            expected_exists = arguments.get("expected_exists")
            if not isinstance(expected_exists, bool):
                raise FilesystemEffectError(
                    "expected_exists must be a boolean",
                    code="filesystem_precondition_invalid",
                )
            exists = target.is_file()
            if exists != expected_exists:
                raise FilesystemEffectError(
                    "Filesystem target existence changed after authorization",
                    code="filesystem_precondition_stale",
                )
            expected_digest = str(arguments.get("expected_sha256") or "").strip().lower()
            if expected_exists:
                if len(expected_digest) != 64 or any(ch not in "0123456789abcdef" for ch in expected_digest):
                    raise FilesystemEffectError(
                        "Modify requires expected_sha256",
                        code="filesystem_precondition_invalid",
                    )
                import hashlib

                actual_digest = hashlib.sha256(target.read_bytes()).hexdigest()
                if actual_digest != expected_digest:
                    raise FilesystemEffectError(
                        "Filesystem target content changed after authorization",
                        code="filesystem_precondition_stale",
                    )
            elif expected_digest:
                raise FilesystemEffectError(
                    "Create must not include expected_sha256",
                    code="filesystem_precondition_invalid",
                )
        except FilesystemEffectError as exc:
            raise ExecutionGatewayError(str(exc), code=exc.code, pre_dispatch=True) from exc
        except OSError as exc:
            raise ExecutionGatewayError(
                f"Filesystem target could not be revalidated: {exc}",
                code="filesystem_precondition_stale",
                pre_dispatch=True,
            ) from exc

    def execute(self, request: ExecutionRequest, context: ExecutionContext) -> Any:
        from filesystem_effects import FilesystemEffectError, write_file_effect

        manager = context.manager
        if manager is None:
            raise ExecutionGatewayError(
                "Filesystem write requires SessionManager context",
                code="execution_context_manager_required",
            )
        if not isinstance(context.services.get("_authorization"), dict):
            raise ExecutionGatewayError(
                "Filesystem write requires gateway-owned authorization context",
                code="execution_authorization_context_required",
            )
        manager_session = str(getattr(manager, "session_id", "") or "")
        if manager_session and manager_session != request.session_id:
            raise ExecutionGatewayError(
                "ExecutionContext manager belongs to another session",
                code="execution_context_session_mismatch",
            )
        raw_path = str(request.target.get("path") or "").strip()
        arguments = request.arguments if isinstance(request.arguments, dict) else {}
        content = str(arguments.get("content") or "")
        try:
            return write_file_effect(
                manager,
                raw_path,
                content,
                expected_exists=arguments.get("expected_exists") if "expected_exists" in arguments else None,
                expected_sha256=arguments.get("expected_sha256") if "expected_exists" in arguments else None,
            )
        except FilesystemEffectError as exc:
            raise ExecutionGatewayError(str(exc), code=exc.code) from exc


class FilesystemReadEffectAdapter:
    """Gateway-owned adapter for one scoped, read-only plan child."""

    effect_ids = frozenset({"filesystem.read"})

    def execute(self, request: ExecutionRequest, context: ExecutionContext) -> Any:
        from filesystem_effects import FilesystemEffectError, read_file_effect

        manager = context.manager
        if manager is None:
            raise ExecutionGatewayError(
                "Filesystem read requires SessionManager context",
                code="execution_context_manager_required",
            )
        if not isinstance(context.services.get("_authorization"), dict):
            raise ExecutionGatewayError(
                "Filesystem read requires gateway-owned authorization context",
                code="execution_authorization_context_required",
            )
        manager_session = str(getattr(manager, "session_id", "") or "")
        if manager_session and manager_session != request.session_id:
            raise ExecutionGatewayError(
                "ExecutionContext manager belongs to another session",
                code="execution_context_session_mismatch",
            )
        try:
            return read_file_effect(manager, str(request.target.get("path") or ""))
        except FilesystemEffectError as exc:
            raise ExecutionGatewayError(str(exc), code=exc.code) from exc
