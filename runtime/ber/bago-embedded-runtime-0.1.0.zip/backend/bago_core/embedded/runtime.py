"""Composition root for the private BAGO Embedded Runtime."""

from __future__ import annotations

import importlib
import os
import sys
import uuid
from pathlib import Path
from typing import Any


def _install_source_paths() -> Path:
    backend_root = Path(__file__).resolve().parents[2]
    for candidate in (backend_root / ".bago" / "core", backend_root / ".bago" / "api"):
        value = str(candidate.resolve())
        if value not in sys.path:
            sys.path.insert(0, value)
    return backend_root


BACKEND_ROOT = _install_source_paths()

from .manifest import BER_VERSION, EFFECTS, PROTOCOL_VERSION, read_manifest
from .session import EmbeddedSession
from execution_adapter_contract import ExecutionGatewayError


class EmbeddedRuntime:
    """BAGO authority and adapters behind a bounded local protocol."""

    def __init__(
        self,
        *,
        workspace: str | os.PathLike[str],
        state_root: str | os.PathLike[str],
        runtime_root: str | os.PathLike[str] | None = None,
        session_id: str | None = None,
    ) -> None:
        runtime_root_path = Path(runtime_root or BACKEND_ROOT).expanduser().resolve(strict=True)
        self.session = EmbeddedSession(
            session_id=session_id or f"ber-session-{uuid.uuid4().hex}",
            project_root=Path(workspace),
            state_root=Path(state_root),
            runtime_root=runtime_root_path,
            framework_root=runtime_root_path,
        )
        # Import only after BER has bound private BAGO state roots.
        prior_mode = os.environ.get("BAGO_EMBEDDED_RUNTIME")
        os.environ["BAGO_EMBEDDED_RUNTIME"] = "1"
        try:
            profile_module = importlib.import_module("bago_core.embedded.profile")
            gateway_module = importlib.import_module("execution_gateway")
        finally:
            if prior_mode is None:
                os.environ.pop("BAGO_EMBEDDED_RUNTIME", None)
            else:
                os.environ["BAGO_EMBEDDED_RUNTIME"] = prior_mode
        self._profile = profile_module
        boundary_module = importlib.import_module("authorization_boundary")
        context_module = importlib.import_module("execution_adapter_contract")
        request_module = importlib.import_module("world_state_snapshot")
        self._boundary = boundary_module.AuthorizationBoundary()
        self._gateway = gateway_module.ExecutionGateway(
            boundary=self._boundary,
            adapters=self._profile.build_embedded_effect_adapter_registry(),
        )
        self._context_type = context_module.ExecutionContext
        self._request_builder = request_module.build_execution_request_with_snapshot
        self._requests: dict[str, Any] = {}
        self._permits: dict[str, str] = {}
        self._interactions: dict[str, str] = {}

    @property
    def manifest(self) -> dict[str, Any]:
        return read_manifest()

    def status(self) -> dict[str, Any]:
        return {
            "healthy": True,
            "ber_version": BER_VERSION,
            "protocol_version": PROTOCOL_VERSION,
            "source_commit": self.manifest["source_commit"],
            "artifact_sha256": self.manifest.get("artifact_sha256", "NOT_BOUND"),
            "session_id": self.session.session_id,
            "workspace": str(self.session.project_root),
            "effects": list(self._profile.BER_EFFECTS),
            "blocked_effects": self.manifest["blocked_effects"],
        }

    def _build_request(self, operation: dict[str, Any]) -> Any:
        effect_id = str(operation.get("effect_id") or "").strip()
        if effect_id not in self._gateway.adapters.registered_effects():
            raise ExecutionGatewayError("effect_id is not available in the BER profile", code="ber_effect_unavailable")
        target = operation.get("target")
        arguments = operation.get("arguments", {})
        if not isinstance(target, dict) or not isinstance(arguments, dict):
            raise ExecutionGatewayError("target and arguments must be JSON objects", code="ber_request_invalid")
        preconditions = operation.get("preconditions", [])
        if not isinstance(preconditions, list) or not all(isinstance(item, str) for item in preconditions):
            raise ExecutionGatewayError("preconditions must be a list of strings", code="ber_request_invalid")
        if effect_id == "process.inspect":
            registry = importlib.import_module("effect_registry").REGISTRY
            actor_kind = "server"
            principal_id = "bago-ber-runtime"
            source_surface = "server.ber.stdio"
            policy_version = registry.digest
        else:
            actor_kind = "user"
            principal_id = str(operation.get("principal_id") or "local-user")
            source_surface = "adl.ber.stdio"
            policy_version = "ber-policy-v0.1"
        request = self._request_builder(
            self.session,
            effect_id=effect_id,
            actor_kind=actor_kind,
            principal_id=principal_id,
            session_id=self.session.session_id,
            source_surface=source_surface,
            target=target,
            arguments=arguments,
            scope=str(self.session.project_root),
            policy_version=policy_version,
            preconditions=tuple(preconditions),
        )
        adapter = self._gateway.adapters.resolve(effect_id)
        validate_request = getattr(adapter, "validate_request", None)
        if callable(validate_request):
            validate_request(request, self._context_type(manager=self.session))
        else:
            revalidate = getattr(adapter, "revalidate_world_state", None)
            if callable(revalidate):
                revalidate(request, self._context_type(manager=self.session))
        return request

    def prepare(self, operation: dict[str, Any]) -> dict[str, Any]:
        request = self._build_request(operation)
        if request.effect_id == "process.inspect":
            challenge_id = f"ber-query-{uuid.uuid4().hex}"
            interaction_id = ""
            expires_at = ""
            approval_required = False
        else:
            interaction_id = f"ber-interaction-{uuid.uuid4().hex}"
            challenge = self._boundary.create_challenge(request, interaction_id=interaction_id)
            challenge_id = str(challenge["challenge_id"])
            expires_at = challenge["expires_at"]
            approval_required = True
        self._requests[challenge_id] = request
        if interaction_id:
            self._interactions[challenge_id] = interaction_id
        return {
            "challenge_id": challenge_id,
            "interaction_id": interaction_id,
            "request_id": request.request_id,
            "operation_fingerprint": request.fingerprint,
            "effect_id": request.effect_id,
            "target": request.target,
            "arguments_digest": request.arguments_digest,
            "world_state_digest": request.world_state_digest,
            "expires_at": expires_at,
            "approval_required": approval_required,
        }

    def approve(self, challenge_id: str, *, channel: str = "desktop") -> dict[str, Any]:
        request = self._requests.get(challenge_id)
        interaction_id = self._interactions.get(challenge_id)
        if request is None or request.effect_id == "process.inspect" or not interaction_id:
            raise ExecutionGatewayError("BER challenge is unknown or already used", code="ber_challenge_replay")
        approved = self._boundary.approve_challenge(
            challenge_id=challenge_id,
            interaction_id=interaction_id,
            session_id=request.session_id,
            channel=channel,
        )
        self._permits[challenge_id] = str(approved["permit"]["token"])
        return {
            "challenge_id": challenge_id,
            "request_id": request.request_id,
            "decision_id": approved["decision"]["decision_id"],
            "proof_id": approved["proof"]["proof_id"],
            "effect_id": request.effect_id,
            "state": "approved",
        }

    def execute(self, challenge_id: str) -> dict[str, Any]:
        request = self._requests.get(challenge_id)
        if request is None:
            raise ExecutionGatewayError("BER challenge is unknown or already used", code="ber_challenge_replay")
        effect_id = request.effect_id
        context = self._context_type(manager=self.session)
        if effect_id == "process.inspect":
            result, authorization = self._gateway.execute_server_owned(request=request, context=context)
        else:
            token = self._permits.pop(challenge_id, None)
            if not token:
                raise ExecutionGatewayError("BER execution requires approval", code="ber_approval_required")
            result, authorization = self._gateway.execute(permit_token=token, request=request, context=context)
        self._requests.pop(challenge_id, None)
        self._interactions.pop(challenge_id, None)
        return {
            "ber_execution_id": f"ber-exec-{uuid.uuid4().hex}",
            "request_id": request.request_id,
            "session_id": request.session_id,
            "effect_id": effect_id,
            "authorization": {
                "state": authorization.get("state"),
                "decision_id": authorization.get("decision_id"),
                "proof_id": authorization.get("proof_id"),
                "permit_id": authorization.get("permit_id"),
            },
            "result": result,
            "receipt_id": result.get("receipt_id") if isinstance(result, dict) else "",
        }


__all__ = ["EmbeddedRuntime"]
