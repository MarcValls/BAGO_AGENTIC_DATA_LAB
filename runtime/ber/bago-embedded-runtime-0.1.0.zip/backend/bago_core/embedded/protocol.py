"""Strict JSON-lines protocol for BER's private stdio transport."""

from __future__ import annotations

import json
from typing import Any

PROTOCOL_VERSION = "bago.ber.ipc/v1"
MAX_MESSAGE_BYTES = 1_048_576
ALLOWED_ACTIONS = frozenset({"health", "prepare", "approve", "execute", "shutdown"})


class ProtocolError(ValueError):
    def __init__(self, message: str, *, code: str = "ber_protocol_invalid") -> None:
        super().__init__(message)
        self.code = code


def decode_message(raw: bytes) -> dict[str, Any]:
    if len(raw) > MAX_MESSAGE_BYTES:
        raise ProtocolError("BER message exceeds the size limit", code="ber_protocol_message_too_large")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("BER message is not valid UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise ProtocolError("BER message must be a JSON object")
    if value.get("protocol_version") != PROTOCOL_VERSION:
        raise ProtocolError("BER protocol version mismatch", code="ber_protocol_version_mismatch")
    action = value.get("action")
    if action not in ALLOWED_ACTIONS:
        raise ProtocolError("BER action is unavailable", code="ber_protocol_action_unavailable")
    if not isinstance(value.get("request_id"), str) or not value["request_id"].strip():
        raise ProtocolError("request_id is required")
    return value


def encode_message(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


__all__ = ["PROTOCOL_VERSION", "MAX_MESSAGE_BYTES", "ALLOWED_ACTIONS", "ProtocolError", "decode_message", "encode_message"]
