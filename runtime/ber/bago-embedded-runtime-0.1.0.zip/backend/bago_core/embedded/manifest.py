"""Identity for the source-derived BER profile."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

BER_VERSION = "0.1.0"
PROTOCOL_VERSION = "bago.ber.ipc/v1"
SOURCE_COMMIT = "5fb6f2f0c57f29de1b42bbb2efb4a57c86aa032d"
PROFILE_ID = "bago-embedded-runtime/filesystem-process-v0.1"
EFFECTS = ["filesystem.read", "filesystem.write", "process.execute", "process.inspect"]
BLOCKED_EFFECTS = ["filesystem.delete", "process.terminate"]


def read_manifest(path: Path | None = None) -> dict[str, Any]:
    source = path or Path(__file__).with_name("ber-manifest.json")
    if source.is_file():
        payload = json.loads(source.read_text(encoding="utf-8"))
        if payload.get("source_commit") != SOURCE_COMMIT or payload.get("ber_version") != BER_VERSION:
            raise ValueError("BER manifest does not match the embedded source identity")
        payload["artifact_sha256"] = os.environ.get(
            "BAGO_BER_ARTIFACT_SHA256", str(payload.get("artifact_sha256") or "NOT_BOUND")
        )
        return payload
    return {
        "schema": "bago.embedded-runtime.manifest.v1",
        "ber_version": BER_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "source_repository": "MarcValls/BAGO",
        "source_commit": SOURCE_COMMIT,
        "profile_id": PROFILE_ID,
        "effects": list(EFFECTS),
        "blocked_effects": list(BLOCKED_EFFECTS),
        "artifact_sha256": "NOT_BUILT",
    }


__all__ = ["BER_VERSION", "PROTOCOL_VERSION", "SOURCE_COMMIT", "PROFILE_ID", "read_manifest"]
