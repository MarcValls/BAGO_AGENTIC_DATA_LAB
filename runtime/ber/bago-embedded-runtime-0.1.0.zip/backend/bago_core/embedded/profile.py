"""Explicit least-authority profile for BER v0.1."""

from __future__ import annotations

import hashlib
import os
import re
import sys
import subprocess
import uuid
from pathlib import Path
from typing import Any

from execution_adapter_contract import ExecutionContext, ExecutionGatewayError
from execution_adapters.filesystem import FilesystemEffectAdapter, FilesystemReadEffectAdapter
from execution_gateway import EffectAdapterRegistry
from execution_request import ExecutionRequest


BER_EFFECTS = (
    "filesystem.read",
    "filesystem.write",
    "process.inspect",
    "process.execute",
)
BER_BLOCKED_EFFECTS = ("filesystem.delete", "process.terminate")
_GIT_READ_ONLY = {
    ("rev-parse", "HEAD"),
    ("rev-parse", "--show-toplevel"),
    ("rev-parse", "--abbrev-ref", "HEAD"),
    ("status", "--porcelain=v1", "--untracked-files=all"),
    ("diff", "--name-only"),
    ("branch", "--show-current"),
}


def _workspace_path(manager: Any, raw_path: Any) -> Path:
    clean = str(raw_path or "").strip().replace("\\", "/")
    if not clean or clean.startswith("/") or re.match(r"^[A-Za-z]:", clean):
        raise ExecutionGatewayError("BER filesystem paths must be workspace-relative", code="filesystem_path_out_of_scope")
    if any(part in {"", ".", ".."} for part in clean.split("/")):
        raise ExecutionGatewayError("BER filesystem path is not canonical", code="filesystem_path_invalid")
    root = Path(str(getattr(manager, "project_root", "") or "")).resolve(strict=True)
    candidate = (root / Path(*clean.split("/"))).resolve(strict=False)
    if candidate != root and root not in candidate.parents:
        raise ExecutionGatewayError("BER filesystem path escapes the workspace", code="filesystem_path_out_of_scope")
    return candidate


class EmbeddedFilesystemWriteAdapter(FilesystemEffectAdapter):
    """BAGO canonical write adapter narrowed to the BER workspace profile."""

    def revalidate_world_state(self, request: ExecutionRequest, context: ExecutionContext) -> None:
        _workspace_path(context.manager, request.target.get("path"))
        super().revalidate_world_state(request, context)


class EmbeddedFilesystemReadAdapter(FilesystemReadEffectAdapter):
    """BAGO canonical read adapter narrowed to workspace-relative paths."""

    def validate_request(self, request: ExecutionRequest, context: ExecutionContext) -> None:
        _workspace_path(context.manager, request.target.get("path"))

    def execute(self, request: ExecutionRequest, context: ExecutionContext) -> Any:
        self.validate_request(request, context)
        return super().execute(request, context)


class EmbeddedProcessAdapter:
    """Expose only fixed, shell-free process queries and tests."""

    effect_ids = frozenset({"process.inspect", "process.execute"})
    server_policy_effects = frozenset({"process.inspect"})

    @staticmethod
    def _argv(request: ExecutionRequest) -> list[str] | None:
        arguments = request.arguments if isinstance(request.arguments, dict) else {}
        values = arguments.get("argv")
        if not isinstance(values, list) or not all(isinstance(item, str) for item in values):
            return None
        return values

    @staticmethod
    def _workspace(manager: Any, target: dict[str, Any]) -> bool:
        cwd = str(target.get("cwd") or "").strip()
        if not cwd:
            return True
        try:
            root = Path(str(getattr(manager, "project_root", ""))).resolve(strict=True)
            selected = Path(cwd).resolve(strict=True) if Path(cwd).is_absolute() else (root / cwd).resolve(strict=True)
            return selected == root or root in selected.parents
        except (OSError, RuntimeError, ValueError):
            return False

    def _validate(self, request: ExecutionRequest, context: ExecutionContext) -> None:
        target = request.target if isinstance(request.target, dict) else {}
        argv = self._argv(request)
        executable = str(target.get("executable") or "").strip()
        if target.get("command") or target.get("python_script") or target.get("python_module"):
            raise ExecutionGatewayError("BER does not accept free-form command fields", code="ber_process_profile_denied")
        if not self._workspace(context.manager, target):
            raise ExecutionGatewayError("BER process cwd escapes the workspace", code="process_execution_cwd_out_of_scope")
        timeout = target.get("timeout_seconds", 30 if request.effect_id == "process.inspect" else 120)
        try:
            timeout_value = float(timeout)
        except (TypeError, ValueError) as exc:
            raise ExecutionGatewayError("BER process timeout is invalid", code="process_execution_timeout_invalid") from exc
        limit = 30 if request.effect_id == "process.inspect" else 120
        if timeout_value <= 0 or timeout_value > limit:
            raise ExecutionGatewayError("BER process timeout exceeds profile", code="process_execution_timeout_invalid")
        if executable == "git" and argv is not None and tuple(argv) in _GIT_READ_ONLY:
            return
        if request.effect_id == "process.execute" and os.path.normcase(os.path.realpath(executable)) == os.path.normcase(os.path.realpath(sys.executable)):
            if argv and len(argv) >= 2 and argv[:2] == ["-m", "pytest"] and len(argv) <= 130:
                if all("\x00" not in value and len(value) <= 4096 for value in argv):
                    return
        raise ExecutionGatewayError("Process operation is not in the BER v0.1 typed profile", code="ber_process_profile_denied")

    def validate_request(self, request: ExecutionRequest, context: ExecutionContext) -> None:
        self._validate(request, context)

    def execute(self, request: ExecutionRequest, context: ExecutionContext) -> Any:
        self._validate(request, context)
        target = request.target
        argv = self._argv(request) or []
        executable = str(target.get("executable") or "").strip()
        if os.path.normcase(os.path.realpath(executable)) == os.path.normcase(os.path.realpath(sys.executable)):
            executable_path = sys.executable
            command = [executable_path, *argv]
        else:
            from shutil import which

            executable_path = which(executable)
            if not executable_path:
                raise ExecutionGatewayError("BER process executable is unavailable", code="process_execution_executable_unavailable")
            command = [executable_path, *argv]
        root = Path(str(context.manager.project_root)).resolve(strict=True)
        cwd_value = str(target.get("cwd") or "").strip()
        cwd = (Path(cwd_value) if Path(cwd_value).is_absolute() else root / cwd_value).resolve(strict=True) if cwd_value else root
        if cwd != root and root not in cwd.parents:
            raise ExecutionGatewayError("BER process cwd escapes the workspace", code="process_execution_cwd_out_of_scope")
        env = {
            key: os.environ[key]
            for key in ("PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "HOME", "USERPROFILE")
            if os.environ.get(key)
        }
        env.update({
            "PYTHONUTF8": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": os.devnull,
            "GIT_CONFIG_SYSTEM": os.devnull,
            "GIT_TERMINAL_PROMPT": "0",
        })
        python_runner = os.path.normcase(os.path.realpath(executable)) == os.path.normcase(os.path.realpath(sys.executable))
        if python_runner and os.name == "nt":
            appdata = os.environ.get("APPDATA")
            user_profile = env.get("USERPROFILE")
            if appdata and user_profile:
                try:
                    appdata_path = Path(appdata).resolve(strict=True)
                    appdata_path.relative_to(Path(user_profile).resolve(strict=True))
                except (OSError, RuntimeError, ValueError):
                    pass
                else:
                    # Python resolves its Windows user-site from APPDATA. Keep
                    # this single user-scoped path so an approved typed pytest
                    # run can use the active interpreter's installed modules.
                    env["APPDATA"] = appdata
        try:
            completed = subprocess.run(
                command,
                cwd=str(cwd),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=float(target.get("timeout_seconds", 30 if request.effect_id == "process.inspect" else 120)),
                check=False,
                shell=False,
                env=env,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise ExecutionGatewayError(f"BER process operation failed: {exc}", code="process_execution_failed") from exc
        stdout = str(completed.stdout or "")
        stderr = str(completed.stderr or "")
        if len(stdout.encode("utf-8")) + len(stderr.encode("utf-8")) > 1_048_576:
            raise ExecutionGatewayError("BER process output exceeds the profile limit", code="ber_process_output_too_large")
        output_digest = hashlib.sha256((stdout + "\x00" + stderr).encode("utf-8")).hexdigest()
        receipt_id = f"bago-ber-process:sha256:{hashlib.sha256((request.fingerprint + output_digest).encode()).hexdigest()}"
        return {
            "ok": completed.returncode == 0,
            "executed": True,
            "effect_id": request.effect_id,
            "operation": "typed_process",
            "executable": Path(executable_path).name,
            "argv": argv,
            "cwd": str(cwd),
            "returncode": int(completed.returncode),
            "stdout": stdout[:65536],
            "stderr": stderr[:65536],
            "stdout_sha256": hashlib.sha256(stdout.encode("utf-8")).hexdigest(),
            "stderr_sha256": hashlib.sha256(stderr.encode("utf-8")).hexdigest(),
            "output_sha256": output_digest,
            "receipt_id": receipt_id,
        }


def build_embedded_effect_adapter_registry() -> EffectAdapterRegistry:
    registry = EffectAdapterRegistry()
    registry.register(EmbeddedFilesystemReadAdapter())
    registry.register(EmbeddedFilesystemWriteAdapter())
    registry.register(EmbeddedProcessAdapter())
    if registry.registered_effects() != tuple(sorted(BER_EFFECTS)):
        raise ExecutionGatewayError("BER adapter profile differs from the frozen effect list", code="ber_profile_invalid")
    return registry


__all__ = ["BER_EFFECTS", "BER_BLOCKED_EFFECTS", "build_embedded_effect_adapter_registry"]
