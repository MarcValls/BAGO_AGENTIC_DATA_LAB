"""BAGO Embedded Runtime public surface."""

from .runtime import EmbeddedRuntime

__all__ = ["EmbeddedRuntime"]
