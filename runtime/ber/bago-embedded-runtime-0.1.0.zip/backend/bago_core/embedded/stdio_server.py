"""Serve BER over a private stdin/stdout JSON-lines channel."""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path
from typing import Any

from .protocol import MAX_MESSAGE_BYTES, PROTOCOL_VERSION, ProtocolError, decode_message, encode_message
from .runtime import EmbeddedRuntime


def _response(runtime: EmbeddedRuntime, message: dict[str, Any]) -> dict[str, Any]:
    action = message["action"]
    allowed_fields = {
        "health": {"protocol_version", "request_id", "action"},
        "prepare": {"protocol_version", "request_id", "action", "operation"},
        "approve": {"protocol_version", "request_id", "action", "challenge_id", "channel"},
        "execute": {"protocol_version", "request_id", "action", "challenge_id"},
        "shutdown": {"protocol_version", "request_id", "action"},
    }[action]
    if set(message) - allowed_fields:
        raise ProtocolError("BER message contains unsupported fields")
    if action == "health":
        result = runtime.status()
    elif action == "prepare":
        operation = message.get("operation")
        if not isinstance(operation, dict):
            raise ProtocolError("operation must be a JSON object")
        allowed = {"effect_id", "target", "arguments", "principal_id", "preconditions"}
        if set(operation) - allowed:
            raise ProtocolError("operation contains unsupported fields")
        result = runtime.prepare(operation)
    elif action == "approve":
        challenge_id = str(message.get("challenge_id") or "")
        channel = str(message.get("channel") or "desktop")
        if channel not in {"desktop", "ui-react"}:
            raise ProtocolError("approval channel is unavailable", code="authorization_user_origin_unverified")
        result = runtime.approve(challenge_id, channel=channel)
    elif action == "execute":
        result = runtime.execute(str(message.get("challenge_id") or ""))
    elif action == "shutdown":
        result = {"shutdown": True}
    else:  # decode_message already closes this set
        raise ProtocolError("BER action is unavailable", code="ber_protocol_action_unavailable")
    return {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": message["request_id"],
        "ok": True,
        "result": result,
    }


def serve(runtime: EmbeddedRuntime, *, stdin: Any = None, stdout: Any = None) -> int:
    reader = stdin or sys.stdin.buffer
    writer = stdout or sys.stdout.buffer
    while True:
        raw_line = reader.readline(MAX_MESSAGE_BYTES + 2)
        if not raw_line:
            break
        request_id = ""
        try:
            if len(raw_line) > MAX_MESSAGE_BYTES + 1 or not raw_line.endswith(b"\n"):
                raise ProtocolError("BER message exceeds the size limit", code="ber_protocol_message_too_large")
            message = decode_message(raw_line.rstrip(b"\r\n"))
            request_id = message["request_id"]
            response = _response(runtime, message)
            writer.write(encode_message(response))
            writer.flush()
            if message["action"] == "shutdown":
                return 0
        except Exception as exc:
            code = str(getattr(exc, "code", "ber_runtime_error"))
            writer.write(encode_message({
                "protocol_version": PROTOCOL_VERSION,
                "request_id": request_id,
                "ok": False,
                "error": {"code": code, "message": str(exc)[:2048]},
            }))
            writer.flush()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Private BAGO Embedded Runtime stdio endpoint")
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--state-root", required=True)
    parser.add_argument("--runtime-root", default=str(Path(__file__).resolve().parents[2]))
    args = parser.parse_args(argv)
    try:
        runtime = EmbeddedRuntime(workspace=args.workspace, state_root=args.state_root, runtime_root=args.runtime_root)
        return serve(runtime)
    except Exception as exc:
        sys.stderr.write(f"BER startup failed: {getattr(exc, 'code', 'ber_startup_failed')}: {exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
