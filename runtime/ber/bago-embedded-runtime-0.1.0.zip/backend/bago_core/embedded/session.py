"""Private workspace and state roots for one BER process."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class EmbeddedSession:
    session_id: str
    project_root: Path
    state_root: Path
    runtime_root: Path
    framework_root: Path

    def __post_init__(self) -> None:
        if not self.session_id.strip():
            raise ValueError("session_id is required")
        project = self.project_root.expanduser().resolve(strict=True)
        if not project.is_dir():
            raise ValueError("project_root must be a directory")
        state = self.state_root.expanduser().resolve(strict=False)
        runtime = self.runtime_root.expanduser().resolve(strict=True)
        object.__setattr__(self, "project_root", project)
        object.__setattr__(self, "state_root", state)
        object.__setattr__(self, "runtime_root", runtime)
        state.mkdir(parents=True, exist_ok=True)
        os.environ["BAGO_STATE_ROOT"] = str(state)
        os.environ["BAGO_USER_ROOT"] = str(state.parent)
        os.environ["BAGO_RUNTIME_ROOT"] = str(runtime)

    @property
    def base_path(self) -> str:
        return str(self.project_root)

    @property
    def workspace_scope_root(self) -> str:
        return str(self.project_root)

    @property
    def workspace_mirror_root(self) -> str:
        return str(self.project_root)

    @property
    def runtime(self) -> str:
        return "embedded"

    @property
    def context_revision(self) -> str:
        return ""

    def workspace_state(self) -> dict[str, str]:
        return {
            "project_root": str(self.project_root),
            "workspace": str(self.project_root),
            "workspace_state_root": str(self.state_root),
            "context_revision": "",
        }


__all__ = ["EmbeddedSession"]
