import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const pack=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=path.join(pack,'payload/.gabo/frontend-pack/visual');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'bago-ui-selftest-'));
const visual=path.join(tmp,'.gabo/frontend-pack/visual');
fs.mkdirSync(path.dirname(visual),{recursive:true});
fs.cpSync(src,visual,{recursive:true});
const sh=(program,args,cwd=tmp)=>spawnSync(program,args,{cwd,encoding:'utf8',timeout:30000});
const expect=(condition,message)=>{if(!condition) throw Error('SELFTEST FAIL: '+message);};
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const put=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
try {
 expect(sh('git',['init']).status===0,'git init');
 expect(sh('git',['config','user.email','selftest@localhost']).status===0,'git email');
 expect(sh('git',['config','user.name','BAGO SelfTest']).status===0,'git name');
 const baselineDir=path.join(visual,'tests/visual.spec.mjs-snapshots');
 const baselines=['home-desktop-chromium-linux.png','home-mobile-chromium-linux.png'].map(file=>{
  const rel='tests/visual.spec.mjs-snapshots/'+file;
  const dest=path.join(visual,rel);put(dest,'FAKE PNG '+file);return {file:rel,sha256:hash(dest)};
 });
 put(path.join(visual,'baseline-approval.json'), {schema:'bago.visual.baseline-approval/v1',approvedBy:'test-fixture',approvedAt:'2026-01-01T00:00:00Z',gitHead:'synthetic',baselines});
 expect(sh('git',['add','.']).status===0,'git add');
 expect(sh('git',['commit','-m','synthetic fixture']).status===0,'git commit');
 const head=sh('git',['rev-parse','HEAD']).stdout.trim();
 const runId='RUN_SELFTEST_001';const runDir=path.join(tmp,'.gabo/evidence/frontend-visual',runId);
 const context={schema:'bago.visual.run/v1',runId,dateUTC:new Date().toISOString(),repoRoot:tmp,gitHead:head,branch:'main',dirty:false,mode:'compare',baseURL:'http://127.0.0.1:5173',platform:process.platform,arch:process.arch,node:process.version,
  scenarios:[{id:'home',path:'/'}],projects:['desktop-chromium','mobile-chromium'],baselines,
  baselineApproval:{file:'baseline-approval.json',sha256:hash(path.join(visual,'baseline-approval.json'))}};
 const cfg=['runner.mjs','verify-run.mjs','playwright.config.mjs','scenarios.json','tests/visual.spec.mjs','package.json'];
 const config=cfg.map(file=>({file,sha256:hash(path.join(visual,file))}));
 context.configuration=config;
 put(path.join(runDir,'run-context.json'),context);
 put(path.join(runDir,'result.json'),{status:'EXECUTED_COMPARE_PASS_CANDIDATE',exitCode:0,mode:'compare'});
 put(path.join(runDir,'playwright-report.json'),{stats:{expected:2,unexpected:0,flaky:0,skipped:0},suites:[{title:'visual fixture'}]});
 put(path.join(runDir,'artifacts/home-desktop.png'),'FAKE visual fixture PNG');
 put(path.join(runDir,'artifacts/home-mobile.png'),'FAKE visual fixture PNG');
 const files=['run-context.json','result.json','playwright-report.json','artifacts/home-desktop.png','artifacts/home-mobile.png'].map(file=>({file,sha256:hash(path.join(runDir,file))}));
 put(path.join(runDir,'manifest.json'),{schema:'bago.visual.sha-manifest/v1',runId,files,configuration:config,baselineApproval:context.baselineApproval,baselines});
 const verify=()=>sh(process.execPath,[path.join(visual,'verify-run.mjs'),'--run',runDir,'--repo',tmp]);
 const success=verify();expect(success.status===0,'clean compare receipt should PASS: '+success.stdout+success.stderr);
 const safe=sh(process.execPath,[path.join(visual,'runner.mjs'),'--dry-run','--mode','capture','--url','http://127.0.0.1:5173']);
 expect(safe.status===0 && safe.stdout.includes('DRY_RUN'),'local URL dry-run');
 const unsafe=sh(process.execPath,[path.join(visual,'runner.mjs'),'--dry-run','--mode','capture','--url','https://example.org']);
 expect(unsafe.status!==0,'non-loopback blocked');
 const noApproved=sh(process.execPath,[path.join(visual,'runner.mjs'),'--dry-run','--mode','baseline','--url','http://127.0.0.1:5173']);
 expect(noApproved.status!==0,'baseline without approval blocked');
 put(path.join(runDir,'result.json'),{status:'EXECUTED_COMPARE_PASS_CANDIDATE',exitCode:12,mode:'compare'});
 const tamper=verify();expect(tamper.status===1 && tamper.stdout.includes('TAMPER'),'tampered file must FAIL');
 console.log(JSON.stringify({status:'PASS',tests:['synthetic valid evidence -> PASS','tampered evidence -> FAIL','localhost dry-run -> PASS','external URL -> REJECT','unauthorized baseline -> REJECT'],tempFixture:tmp,notes:'No actual Chromium or user Codex runtime exercised.'},null,2));
} finally {fs.rmSync(tmp,{recursive:true,force:true});}
