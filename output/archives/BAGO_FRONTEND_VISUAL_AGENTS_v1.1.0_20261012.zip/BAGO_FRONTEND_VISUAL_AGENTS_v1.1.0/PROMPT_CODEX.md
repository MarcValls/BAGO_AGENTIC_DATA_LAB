# Primer prompt para Codex en VS Code (repo ya instalado)

Usa `$bago-frontend-engineering` para auditar la interfaz frontend de este repositorio **sin editar todavía**.

1. Congela Git HEAD, branch, worktree y detecta el canon real; el contenido de `.gabo/frontend-pack/docs` es provisional hasta ser trazado.
2. Delega a `bago_ui_architecture_auditor` y `bago_ui_state_tracer` la topología UI, navegación, ownership y flujo acción→API→backend→render→test. Después pide a `bago_frontend_auditor` un informe CRIT P0/P1/P2 con archivo/línea/evidencia.
3. Presenta un plan de cambio mínimo y separa los cambios de backend/Electron de los cambios frontend. **No empieces a editar sin aprobación explícita del alcance**.
4. Tras aprobación, encarga implementación a `bago_frontend_engineer`. No toleres refactors colaterales ni archivos ajenos modificados.
5. Pide a `bago_visual_test_operator` primero una captura real con el runner Playwright de `.gabo/frontend-pack/visual`. Si no existe baseline aprobado, devuelve BLOCKED en regresión visual; no lo crees por tu cuenta.
6. Encarga a `bago_frontend_verifier` una revisión independiente y read-only del diff real, recibos, hashes, reporter, contratos y gates. Empieza veredicto por PASS, FAIL o BLOCKED, con P0/P1/P2. No declares VALIDATED.

Quiero identificador CRIT, autor del agente, fecha-hora UTC, Git HEAD, comandos reales, PASS/FAIL/NOT_RUN y artefactos SHA256. No hagas commit, push, merge ni acciones remotas.
