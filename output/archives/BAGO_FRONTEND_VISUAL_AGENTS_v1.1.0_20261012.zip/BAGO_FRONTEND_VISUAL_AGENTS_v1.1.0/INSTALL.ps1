# Requires PowerShell 7+; use: pwsh -NoProfile -File .\INSTALL.ps1 -TargetRoot 'F:\your-repo' [-WithCopilot] [-Replace] [-SetupPlaywright]
[CmdletBinding()]
param(
  [string]$TargetRoot = '.',
  [switch]$WithCopilot,
  [switch]$Replace,
  [switch]$SetupPlaywright,
  [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'payload'
if (-not (Test-Path -LiteralPath $src -PathType Container)) { throw 'payload folder missing' }
$repo = (Resolve-Path -LiteralPath $TargetRoot -ErrorAction Stop).Path
if (-not (Test-Path -LiteralPath $repo -PathType Container)) { throw 'TargetRoot must be a directory' }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git required for provenance' }
$git = & git -C $repo rev-parse --show-toplevel 2>$null
if ($LASTEXITCODE -ne 0 -or -not $git) { throw 'TargetRoot must be in an existing Git repository' }
$actualRoot = (Resolve-Path -LiteralPath ($git -join '')).Path
$normalizedRepo = $repo -replace '[\\/]+$',''
$normalizedRoot = $actualRoot -replace '[\\/]+$',''
if ($normalizedRepo -ne $normalizedRoot) { throw 'Pass exact Git repository root as -TargetRoot' }
$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
$backupRoot = Join-Path $repo ".gabo/frontend-pack/backups/$stamp"
$entries = [System.Collections.Generic.List[object]]::new()
$sourceRootLength = ($src -replace '[\\/]+$','').Length + 1
$files = Get-ChildItem -LiteralPath $src -File -Recurse -Force | Sort-Object FullName
$conflicts = 0
foreach ($file in $files) {
  $relative = $file.FullName.Substring($sourceRootLength).Replace('\','/')
  if (-not $WithCopilot -and $relative.StartsWith('.github/')) { continue }
  $destination = Join-Path $repo $relative
  $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $status = 'ADD'
  if (Test-Path -LiteralPath $destination) {
    $existing = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($existing -eq $hash) { $status = 'UNCHANGED' }
    elseif ($Replace) { $status = 'REPLACE_WITH_BACKUP' }
    else { $status = 'CONFLICT_SKIPPED'; $conflicts++ }
  }
  if (-not $DryRun -and $status -in @('ADD','REPLACE_WITH_BACKUP')) {
    $dir = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    if ($status -eq 'REPLACE_WITH_BACKUP') {
      $backup = Join-Path $backupRoot $relative
      New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
      Copy-Item -LiteralPath $destination -Destination $backup -Force
    }
    Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
  }
  $entries.Add([pscustomobject]@{source=$relative;target=$relative;action=$status;sha256=$hash})
}
$receipt = [ordered]@{
  schema = 'bago.frontend.install/v1'; timestampUTC = (Get-Date).ToUniversalTime().ToString('o');
  package = 'BAGO_FRONTEND_VISUAL_AGENTS_v1.1.0'; repoRoot = $repo;
  copilot = [bool]$WithCopilot; dryRun = [bool]$DryRun; conflicts = $conflicts;
  entries = $entries
}
$receipt | ConvertTo-Json -Depth 8 | Write-Output
if (-not $DryRun) {
  $receiptPath = Join-Path $repo ".gabo/frontend-pack/install-receipt-$stamp.json"
  New-Item -ItemType Directory -Path (Split-Path -Parent $receiptPath) -Force | Out-Null
  $receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
if ($conflicts -gt 0) { throw "$conflicts CONFLICT_SKIPPED: review receipt. Re-run with -Replace ONLY after approving backup/replacement." }
if ($SetupPlaywright -and -not $DryRun) {
  if (-not (Get-Command node -ErrorAction SilentlyContinue) -or -not (Get-Command npm -ErrorAction SilentlyContinue)) { throw 'Node.js and npm required; no Playwright setup performed' }
  $visual = Join-Path $repo '.gabo/frontend-pack/visual'
  Push-Location $visual
  try {
    & npm.cmd install --ignore-scripts
    if ($LASTEXITCODE -ne 0) { throw 'npm install FAIL' }
    & npx.cmd playwright install chromium
    if ($LASTEXITCODE -ne 0) { throw 'playwright install chromium FAIL' }
  } finally { Pop-Location }
}
Write-Host "INSTALL PASS ($($entries.Count) inspected files). Runtime/browser tests NOT_RUN until executed inside the target project."
