# BAGO Frontend Visual Agents — pack v1.1.0

**Paquete para Codex + GitHub Copilot (opcional), Windows 10 / PowerShell 7, React/Vite/TypeScript.** Construido a partir de los diez agentes facilitados. No integra el runtime histórico de BAGO ni modifica BAGO5. Se instala en el repositorio de frontend que seleccione el usuario.

## Iniciar

Extraer ZIP en una carpeta independiente, abrir **PowerShell 7** desde dicha carpeta y ejecutar:

```powershell
pwsh -NoProfile -File .\INSTALL.ps1 -TargetRoot 'F:\ruta\a\tu-repo' -DryRun
pwsh -NoProfile -File .\INSTALL.ps1 -TargetRoot 'F:\ruta\a\tu-repo' -SetupPlaywright
```

Para habilitar los agentes originales de **GitHub Copilot** además de Codex, añadir `-WithCopilot`. Por defecto instala solo Codex + skills compartidas + docs + harness. Nunca modifica `.codex/config.toml`, `AGENTS.md` existente ni `.github/copilot-instructions.md` existente. No ejecuta la aplicación, no produce cambios remotos y no instala MCP persistentes.

**Conflictos:** por defecto bloquea/salta archivos existentes diferentes y genera recibo; `-Replace` realiza backup previo en `.gabo/frontend-pack/backups/<UTC>/...`. Inspeccionar el backup antes de reemplazar. `-DryRun` imprime el plan sin mutar. El parámetro `-SetupPlaywright` descarga dependencias y Chromium *solo si se pide expresamente*, y lo hace después de copiar archivos sin conflicto. No ejecuta scripts de instalación de terceros para npm (`--ignore-scripts`); el binario Chromium sí es descargado desde su proveedor al invocar Playwright.

Para una evaluación de entorno compatible instalar previamente `git`, `node >=20.11`, `npm` y Codex CLI/autenticado. El instalador no modifica la cuenta ni el CLI Codex.

## Ejecutar en el proyecto

Abrir VS Code en la **raíz del repositorio** y en Codex invocar `$bago-frontend-engineering`, solicitando delegación a los agentes especializados. Confirmar su registro y permisos reales. Antes de editar, los documentos bajo `.gabo/frontend-pack/docs` están etiquetados como *plantilla*: no sustituyen al canon del proyecto.

Con la aplicación **local** levantada en `http://127.0.0.1:5173`:

```powershell
node .gabo/frontend-pack/visual/runner.mjs --mode capture --url http://127.0.0.1:5173
```

En una tarea separada y tras aprobación explícita de referencia:

```powershell
node .gabo/frontend-pack/visual/runner.mjs --mode baseline --approve-baseline --approved-by "aprobador" --url http://127.0.0.1:5173
node .gabo/frontend-pack/visual/runner.mjs --mode compare --url http://127.0.0.1:5173
node .gabo/frontend-pack/visual/verify-run.mjs --run ".gabo/evidence/frontend-visual/<ID_RUN_COMPARE>" --repo .
```

La validación independiente humana/agente sigue obligatoria; el verificador offline comprueba manifiesto, SHA y reporter. Una captura NO aprueba regresión. La actualización de baseline necesita autorización y genera `baseline-approval.json`, que se debe revisar.

## Contenido

- `.codex/agents/`: 5 agentes originales Codex normalizados + `bago_visual_test_operator` (6).
- `.github/agents/`: 5 agentes originales Copilot reconciliados + operador de navegador (6, instalación opcional).
- `.agents/skills/`: ingeniería frontend, pruebas visuales, verificación independiente.
- `.gabo/frontend-pack/docs/`: protocolos, ownership, mapa, matrices, contrato de frontera, criterios y compatibilidad.
- `.gabo/frontend-pack/visual/`: harness Playwright aislado con escenarios, runner SHA, verificador de evidencia y README.
- `source-originals/`: 10 archivos entregados, conservados intactos.
- `INDEX.md`, `MANIFEST.json`, `INSTALL.ps1`: trazabilidad Añadir/Sustituir, backup y hashes del paquete.

## Estados y límites

`STATIC_PASS`: contenido generado, manifiestos y auto-pruebas offline. `TARGET_NOT_RUN`: sin acceso al Codex/VS Code/Windows/repositorio del usuario. `BROWSER_NOT_RUN`: no hemos ejecutado Chromium del frontend real ni autenticado en Codex del usuario. Ver `COMPATIBILITY_REPORT.md`. No mezclar verificación estática con funcionamiento operacional.
