# ÍNDICE — Añadir / Sustituir — v1.1.0

## Origen y compatibilidad

`source-originals/` contiene byte a byte los 10 archivos adjuntos por el usuario. En `payload/.codex/agents/` se distribuyen 5 agentes normalizados + nuevo operador visual. Se suprimen en **destino** los nombres de modelo de origen para heredar modelos admitidos por la sesión real de Codex; no se modifica el comportamiento funcional de los roles.

| Tipo | Destino relativo | Operación normal | Conflicto |
|---|---|---|---|
| Codex | `.codex/agents/*.toml` | AÑADIR | SALTAR + BLOQUEAR; `-Replace` hace BACKUP y SUSTITUIR |
| Skill | `.agents/skills/*/SKILL.md` | AÑADIR | SALTAR + BLOQUEAR; `-Replace` hace BACKUP y SUSTITUIR |
| Docs de referencia | `.gabo/frontend-pack/docs/*.md` | AÑADIR | SALTAR + BLOQUEAR; `-Replace` hace BACKUP y SUSTITUIR |
| Harness visual | `.gabo/frontend-pack/visual/*` | AÑADIR | SALTAR + BLOQUEAR; `-Replace` hace BACKUP y SUSTITUIR |
| Copilot opcional | `.github/agents/*.agent.md`, `.github/instructions/*` | AÑADIR con `-WithCopilot` | SALTAR + BLOQUEAR; `-Replace` hace BACKUP y SUSTITUIR |

No se crea ni sustituye `AGENTS.md`, `.codex/config.toml`, `.github/copilot-instructions.md` ni archivos fuente reales del frontend. El instalador no elimina nada. `-DryRun` para planificar, `-SetupPlaywright` para instalar dependencias/browser con consentimiento de red.

## Secuencia de aceptación

1. `node scripts/selftest.mjs`: casos offline (valid receipt, manipulación de evidencia, servidor externo, baseline sin autorización, dry-run).
2. `pwsh -File ./INSTALL.ps1 -TargetRoot <repo> -DryRun` (Windows 10/PS 7 destino).
3. `pwsh -File ./INSTALL.ps1 -TargetRoot <repo> -SetupPlaywright [-WithCopilot]`.
4. `codex --version` y agente/skill efectivamente visibles en el cliente real.
5. Captura, baseline aprobada, comparación y `verify-run.mjs`; revisor independiente del parche.

La lista completa, hashes y tamaño de archivos se encuentran en `MANIFEST.json`.
