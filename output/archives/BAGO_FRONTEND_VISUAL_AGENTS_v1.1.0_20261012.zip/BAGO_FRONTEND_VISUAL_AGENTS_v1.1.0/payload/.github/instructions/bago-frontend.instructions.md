---
applyTo: "**/*.{ts,tsx,js,jsx,css,scss}"
---
When modifying frontend, read `.agents/skills/bago-frontend-engineering/SKILL.md` and `.gabo/frontend-pack/docs/FRONTEND_CHANGE_PROTOCOL.md`. These docs are scaffolds, not automatic canon. Do not turn UI into authority; use actual repository contracts. Do not declare VALIDATED independently. Evidence must be fresh and traceable.
