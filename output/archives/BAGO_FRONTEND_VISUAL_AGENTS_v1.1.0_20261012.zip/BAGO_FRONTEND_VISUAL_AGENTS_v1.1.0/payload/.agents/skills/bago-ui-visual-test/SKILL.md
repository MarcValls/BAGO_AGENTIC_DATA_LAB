---
name: bago-ui-visual-test
description: Capturar, comparar y documentar pantallas UI locales con Playwright, errores de consola, overflow, capturas y recibos SHA verificables; usar ante cambios visuales, responsive o regresiones frontend.
---

# Governed visual gate

1. Locate `.gabo/frontend-pack/visual/`. Read README and `docs/VISUAL_ACCEPTANCE.md`.
2. Make sure the app is already running on a **local loopback** port. No implicit server start or external access. Never use credentials or mutable production data.
3. Configure `.gabo/frontend-pack/visual/scenarios.json`: relative paths only. Default `/`.
4. Run `node .gabo/frontend-pack/visual/runner.mjs --mode capture --url http://127.0.0.1:5173`. Capture is **not** a pass of visual regression.
5. For a previously authorized reference, run `--mode compare`. It refuses absent baselines. Never call `--mode baseline` unless the user explicitly approved generating/updating baseline references; baseline creation itself isn't a PASS.
6. Include `run-context.json`, `playwright-report.json`, `manifest.json`, screenshots/trace and exact run folder. The runner never commits.
7. Ask a separate verifier to examine SHA manifests and test output with `verify-run.mjs`. This script is a deterministic evidence checker; it is not a replacement for human or independent-agent review.
8. Do not call layout aesthetics verified from screenshots alone; manual comparison still required for subjective quality.
