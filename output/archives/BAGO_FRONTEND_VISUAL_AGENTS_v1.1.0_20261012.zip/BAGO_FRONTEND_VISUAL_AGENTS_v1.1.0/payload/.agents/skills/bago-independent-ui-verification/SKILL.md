---
name: bago-independent-ui-verification
description: Verificar de forma independiente un parche frontend BAGO frente a contratos, traza de estados, Playwright y hashes de evidencia; usar tras implementar y antes de promocionar cambios.
---

# Independent verifier (read-only)

1. Remain strictly read-only: review *existing* final diff and files, do not rerun tests or edit baselines. Ask the main operator for missing execution gates.
2. Determine HEAD, dirty state, affected feature and canonical source **from actual repository evidence**. Templates are not authority.
3. For every material claim inspect the specific file/symbol, API boundary, ownership and potential behavioral regressions.
4. Examine `run-context.json`, `manifest.json`, and `verdict.json` created by the standalone offline checker; compare evidence timestamp and Git HEAD to final patch. Do not treat a captured screenshot or a fresh baseline as a passing visual regression.
5. Reconcile real traces: action → handler → state owner → network/API → backend authority → response/error → reconciliation → render → test.
6. Check missing/failed tests, console/page errors, accessibility names, desktop/mobile, horizontal overflow, visual comparisons and unauthorized scope changes.
7. Start final report exactly with `PASS`, `FAIL` or `BLOCKED`. Provide severity P0/P1/P2; claim → evidence → conclusion. Label unexecuted evidence NOT_RUN and stale evidence BLOCKED.
8. `PASS` = checked evidence supports scope and independent review; never automatically promote `VALIDATED`.
