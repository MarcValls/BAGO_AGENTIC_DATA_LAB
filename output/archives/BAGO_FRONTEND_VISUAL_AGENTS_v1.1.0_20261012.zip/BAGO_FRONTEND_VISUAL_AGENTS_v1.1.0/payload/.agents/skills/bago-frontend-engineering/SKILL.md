---
name: bago-frontend-engineering
description: Auditar, trazar y reparar cambios React/TypeScript/UI de BAGO con ownership, canon y frontera backend demostrados; usar en cambios frontend, navegación, estado o contratos.
---

# Frontend engineering protocol v1.1.0

1. Capture `git rev-parse HEAD`, `git status --porcelain` and identify repo root/worktree. Never confuse `.gabo/copilot/` with `backend/.bago/`.
2. Read `.gabo/frontend-pack/docs/FRONTEND_CHANGE_PROTOCOL.md`, `UI_SURFACE_MAP.md`, `STATE_OWNERSHIP.md`, and the repository's **actual** canonical instructions. Pack documents are reference scaffolds, not declarations about an unseen repo.
3. Use `bago_ui_architecture_auditor` and `bago_ui_state_tracer` for independent read-only discovery, then `bago_frontend_auditor` for prioritized P0/P1/P2 findings. A file's size alone is never a defect.
4. Produce claim → file:line/symbol → command/observation → impact; distinguish FACT, INFERENCE, CONFLICT, RECOMMENDATION, NOT_RUN.
5. Only with approved scope, assign `bago_frontend_engineer` to the smallest viable frontend patch. Escalate backend/security/canon ownership instead of silently changing it.
6. Delegate browser work to `bago_visual_test_operator` using `$bago-ui-visual-test`. Capture first. Use comparison only after an explicitly approved baseline exists.
7. Delegate final independent read-only review to `bago_frontend_verifier` using `$bago-independent-ui-verification`. The verifier must not trust implementer summaries.
8. Only call a gate PASS if evidence shows it was executed. `VALIDATED` needs a separate explicit promotion; screenshots never prove API authority.

See `.gabo/frontend-pack/docs/VERIFICATION_MATRIX.md` for minimum gates and `.gabo/frontend-pack/docs/REPORT_SCHEMA.md` for final output.
