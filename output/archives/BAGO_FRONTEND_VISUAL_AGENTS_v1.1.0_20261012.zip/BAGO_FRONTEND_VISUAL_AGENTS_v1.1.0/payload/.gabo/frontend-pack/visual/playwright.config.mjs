import { defineConfig } from '@playwright/test';
import path from 'node:path';

const evidenceDir = process.env.BAGO_PW_EVIDENCE_DIR;
if (!evidenceDir) throw new Error('BAGO_PW_EVIDENCE_DIR required; start tests using runner.mjs');

export default defineConfig({
  testDir: './tests',
  timeout: 45_000,
  expect: { timeout: 8_000, toHaveScreenshot: { animations: 'disabled', threshold: 0.15, maxDiffPixelRatio: 0.002 } },
  fullyParallel: false,
  forbidOnly: true,
  retries: 0,
  workers: 1,
  outputDir: path.join(evidenceDir, 'artifacts'),
  reporter: [ ['list'], ['json', { outputFile: path.join(evidenceDir, 'playwright-report.json') }] ],
  use: {
    baseURL: process.env.BAGO_PW_BASE_URL || 'http://127.0.0.1:5173',
    browserName: 'chromium',
    headless: true,
    actionTimeout: 10_000,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure'
  },
  projects: [
    { name: 'desktop-chromium', use: { viewport: { width: 1440, height: 900 } } },
    { name: 'mobile-chromium', use: { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true } }
  ]
});
