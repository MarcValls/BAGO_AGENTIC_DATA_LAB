import { test, expect } from '@playwright/test';
import { readFileSync, mkdirSync, existsSync, copyFileSync } from 'node:fs';
import path from 'node:path';

const visualRoot = path.resolve(import.meta.dirname, '..');
const scenarios = JSON.parse(readFileSync(path.join(visualRoot, 'scenarios.json'), 'utf8'));
const mode = process.env.BAGO_PW_MODE;
if (!['capture', 'compare', 'baseline'].includes(mode)) throw Error('BAGO_PW_MODE invalid');
if (!Array.isArray(scenarios.routes) || !scenarios.routes.length) throw Error('No scenarios defined');
const ids = new Set();
for (const r of scenarios.routes) {
  if (typeof r.id !== 'string' || !/^[a-z0-9][a-z0-9_-]{0,50}$/.test(r.id) || ids.has(r.id)) throw Error('Invalid/duplicate scenario id');
  ids.add(r.id);
  if (typeof r.path !== 'string' || !r.path.startsWith('/') || r.path.startsWith('//') || r.path.includes('\\')) throw Error('Invalid route');
  if (typeof r.readySelector !== 'string' || r.readySelector.length > 250) throw Error('Invalid readySelector');
}

for (const scenario of scenarios.routes) {
  test(`visual ${scenario.id}`, async ({ page }, testInfo) => {
    const base = new URL(process.env.BAGO_PW_BASE_URL);
    const problems = [];
    const isLocal = (address) => {
      const u = new URL(address);
      return ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname) && ['http:', 'https:'].includes(u.protocol);
    };
    await page.route('**/*', async route => {
      const requestURL = route.request().url();
      if (isLocal(requestURL)) await route.continue();
      else { problems.push(`blocked external resource: ${new URL(requestURL).origin}`); await route.abort('blockedbyclient'); }
    });
    page.on('pageerror', error => problems.push(`pageerror: ${error.message}`));
    page.on('console', message => { if (message.type() === 'error') problems.push(`console: ${message.text()}`); });
    page.on('response', res => { if (res.status() >= 500) problems.push(`HTTP ${res.status()}: ${res.url()}`); });
    const address = new URL(scenario.path, base);
    if (address.origin !== base.origin) throw Error('Route escapes local origin');
    await page.goto(address.toString(), { waitUntil: 'domcontentloaded' });
    if (new URL(page.url()).origin !== base.origin) throw Error('Unexpected cross-origin navigation');
    await page.locator(scenario.readySelector).first().waitFor({ state: 'visible', timeout: 12_000 });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(250);
    const actual = testInfo.outputPath(`${scenario.id}-${testInfo.project.name}.png`);
    await page.screenshot({ path: actual, fullPage: true, animations: 'disabled' });
    const layout = await page.evaluate(() => {
      const documentWidth = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);
      const missing = [];
      document.querySelectorAll('img:not([alt])').forEach(x => missing.push(`img ${x.outerHTML.slice(0, 120)}`));
      document.querySelectorAll('button').forEach(x => {
        const name = (x.getAttribute('aria-label') || x.getAttribute('title') || x.textContent || '').trim();
        if (!name && !x.querySelector('img[alt]:not([alt=""])')) missing.push(`button ${x.outerHTML.slice(0, 120)}`);
      });
      document.querySelectorAll('input:not([type="hidden"])').forEach(x => {
        const name = (x.getAttribute('aria-label') || x.getAttribute('title') || x.labels?.[0]?.textContent || '').trim();
        if (!name) missing.push(`input ${x.outerHTML.slice(0, 120)}`);
      });
      return { documentWidth, viewport: innerWidth, missingNames: missing };
    });
    if (layout.documentWidth > layout.viewport + 2) problems.push(`horizontal overflow: ${layout.documentWidth} > ${layout.viewport}`);
    if (layout.missingNames.length) problems.push(`missing accessible names: ${layout.missingNames.slice(0, 10).join('; ')}`);
    if (mode === 'compare') {
      // Fail closed: toHaveScreenshot normally bootstraps absent references; disallow that path.
      const baseline = testInfo.snapshotPath(`${scenario.id}.png`);
      if (!existsSync(baseline)) throw Error(`Baseline absent: ${baseline}`);
      await expect(page).toHaveScreenshot(`${scenario.id}.png`, { fullPage: true, animations: 'disabled' });
    } else if (mode === 'baseline') {
      if (process.env.BAGO_PW_APPROVED !== 'true') throw Error('Baseline requires explicit approval');
      const baseline = testInfo.snapshotPath(`${scenario.id}.png`);
      mkdirSync(path.dirname(baseline), { recursive: true });
      copyFileSync(actual, baseline);
    }
    expect(problems, `Browser hygiene ${scenario.id} on ${testInfo.project.name}`).toEqual([]);
  });
}
