import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// Standalone deterministic checker: read-only unless --output is explicitly supplied.
const visual = path.dirname(fileURLToPath(import.meta.url));
const defaultRepo = path.resolve(visual,'../../..');
const opts = {};
for(let i=2;i<process.argv.length;i++){
 const arg=process.argv[i];
 if (!['--run','--repo','--output','--max-hours'].includes(arg) || i+1>=process.argv.length) throw Error(`Unexpected argument ${arg}`);
 opts[arg]=process.argv[++i];
}
if(!opts['--run']) throw Error('Usage: node verify-run.mjs --run <run-folder> [--repo <repo-root>] [--max-hours 24] [--output <file>]');
const run=path.resolve(opts['--run']);
const repo=path.resolve(opts['--repo']||defaultRepo);
const maxHours=Number(opts['--max-hours']||24);
if(!Number.isFinite(maxHours)||maxHours<=0||maxHours>168) throw Error('Invalid max-hours');
const findings=[];
const add=(kind,message)=>findings.push({kind,message});
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const readJson=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const contained=(root,rel)=>typeof rel==='string' && rel!=='' && !path.isAbsolute(rel) && !rel.split(/[\\/]/).includes('..') && path.resolve(root,rel).startsWith(path.resolve(root)+path.sep);
const manifestPath=path.join(run,'manifest.json');
let manifest, context, result, report;
try {
 manifest=readJson(manifestPath);
 context=readJson(path.join(run,'run-context.json'));
 result=readJson(path.join(run,'result.json'));
 if(fs.existsSync(path.join(run,'playwright-report.json'))) report=readJson(path.join(run,'playwright-report.json'));
} catch(e) {
 console.log(JSON.stringify({status:'BLOCKED',findings:[{kind:'MISSING_EVIDENCE',message:e.message}]},null,2));
 process.exit(2);
}
if(manifest.schema!=='bago.visual.sha-manifest/v1'||context.schema!=='bago.visual.run/v1'||manifest.runId!==context.runId||context.runId!==path.basename(run)) add('SCHEMA','Manifest/context/run_id mismatch');
if(!Array.isArray(manifest.files)||!manifest.files.length) add('MISSING_EVIDENCE','Empty SHA manifest');
else {
 const known=new Set();
 for(const item of manifest.files){
  if(!contained(run,item.file)||known.has(item.file)) {add('MANIFEST','Unsafe or duplicate manifest entry');continue;}
  known.add(item.file);const file=path.resolve(run,item.file);
  if(!fs.existsSync(file)||hash(file)!==item.sha256) add('TAMPER',`Missing or SHA mismatch: ${item.file}`);
 }
 const actual=[];
 function collect(dir){for(const de of fs.readdirSync(dir,{withFileTypes:true})) {
  const p=path.join(dir,de.name);
  if(de.isDirectory()) collect(p);
  if(de.isFile()&&p!==manifestPath) actual.push(path.relative(run,p).replaceAll('\\','/'));
 }}
 collect(run);
 for(const file of actual) if(!known.has(file)) add('UNTRACKED_EVIDENCE',file);
}
if(!Array.isArray(manifest.configuration)||manifest.configuration.length<4) add('CONFIG','Configuration hashes missing');
else for(const item of manifest.configuration){
 if(!contained(visual,item.file)) {add('CONFIG','Unsafe config path');continue;}
 const f=path.resolve(visual,item.file);
 if(!fs.existsSync(f)||hash(f)!==item.sha256) add('STALE_CONFIG',item.file);
}
if(!['capture','compare','baseline'].includes(context.mode)||result.mode!==context.mode) add('SCHEMA','Invalid mode');
const dateMs=Date.parse(context.dateUTC);
if(!Number.isFinite(dateMs)||Date.now()-dateMs>maxHours*3600_000||dateMs-Date.now()>180_000) add('STALE','Evidence outside requested freshness window');
const repoGit=spawnSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8',timeout:7000});
const currentHead=repoGit.status===0?repoGit.stdout.trim():null;
if(!currentHead||!context.gitHead) add('GIT','Git HEAD unavailable, cannot tie evidence to code');
else if(currentHead!==context.gitHead) add('STALE_HEAD',`HEAD changed: ${context.gitHead} → ${currentHead}`);
if(path.resolve(context.repoRoot||'')!==repo) add('REPO','Evidence belongs to different repo');
if(context.mode!=='compare') add('NOT_VISUAL_VERIFIED',`${context.mode} is not a baseline regression comparison`);
if(context.mode==='compare') {
 if(!manifest.baselineApproval||!Array.isArray(manifest.baselines)||!manifest.baselines.length) add('BASELINE','Approved baselines absent');
 else {
  const approvalFile=path.join(visual,'baseline-approval.json');
  if(!fs.existsSync(approvalFile)||hash(approvalFile)!==manifest.baselineApproval.sha256) add('BASELINE','Approval file altered or missing');
  else {
   const approval=readJson(approvalFile);
   if(!approval.approvedBy||!approval.approvedAt||Date.parse(approval.approvedAt)>dateMs) add('BASELINE','Baseline not demonstrably approved before comparison');
   if(JSON.stringify(approval.baselines)!==JSON.stringify(manifest.baselines)) add('BASELINE','Baseline manifest different from approval');
  }
  for(const item of manifest.baselines){
   if(!contained(visual,item.file)) {add('BASELINE','Unsafe baseline path');continue;}
   const f=path.resolve(visual,item.file);
   if(!fs.existsSync(f)||hash(f)!==item.sha256) add('BASELINE',`Baseline hash mismatch: ${item.file}`);
  }
 }
}
const screenshots = (manifest.files||[]).filter(x => x.file.startsWith('artifacts/') && x.file.endsWith('.png'));
const screenshotMinimum=(context.scenarios?.length||0)*(context.projects?.length||0);
if(screenshots.length < screenshotMinimum || screenshotMinimum < 2) add('MISSING_EVIDENCE',`Only ${screenshots.length}/${screenshotMinimum} screenshot artifacts`);
if(result.exitCode!==0||result.status!=='EXECUTED_COMPARE_PASS_CANDIDATE') add('RUN_FAIL',`Run result not passing comparison: ${result.status}/${result.exitCode}`);
if(!report) add('NOT_RUN','Missing Playwright JSON report');
else {
 const stats=report.stats||{};
 const testCount=Number(stats.expected||0)+Number(stats.unexpected||0)+Number(stats.flaky||0);
 const expectedCount=(context.scenarios?.length||0)*(context.projects?.length||0);
 if(testCount<expectedCount || expectedCount<2) add('COVERAGE',`Expected ${expectedCount} comparisons, got ${testCount}`);
 if(Number(stats.unexpected||0)>0||Number(stats.flaky||0)>0||Number(stats.skipped||0)>0) add('TEST_FAILURE',`Unexpected=${stats.unexpected}, flaky=${stats.flaky}, skipped=${stats.skipped}`);
 if(!Array.isArray(report.suites)||!report.suites.length) add('TEST_FAILURE','Missing suite detail');
}
const status=findings.length?(findings.some(f=>['TAMPER','TEST_FAILURE','RUN_FAIL','BASELINE'].includes(f.kind))?'FAIL':'BLOCKED'):'PASS';
const verdict={schema:'bago.visual.offline-verdict/v1', status, examinedAt:new Date().toISOString(), runId:context.runId,
 repo, head:currentHead, evidenceHead:context.gitHead, checkedBy:'deterministic-offline-checker', findings,
 statement:'Checks integrity, freshness, scenario count and Playwright output; human/agent review still required. SHA is NOT a cryptographic signature.'};
console.log(JSON.stringify(verdict,null,2));
if(opts['--output']) {
 const out=path.resolve(opts['--output']);
 if(!out.startsWith(repo+path.sep)||out.startsWith(run+path.sep)) throw Error('Output must be outside run folder but inside repository');
 fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(verdict,null,2)+'\n');
}
process.exit(status==='PASS'?0:status==='FAIL'?1:2);
