import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

const visual = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(visual, '../../..');
const evidenceRoot = path.join(repo, '.gabo/evidence/frontend-visual');
const options = {};
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (['--dry-run', '--approve-baseline'].includes(a)) { options[a] = true; continue; }
  if (!['--mode','--url','--approved-by'].includes(a) || i + 1 >= process.argv.length) throw Error(`Unknown/missing argument ${a}`);
  options[a] = process.argv[++i];
}
const mode = options['--mode'] || 'capture';
if (!['capture', 'compare', 'baseline'].includes(mode)) throw Error('Allowed modes: capture, compare, baseline');
const target = new URL(options['--url'] || 'http://127.0.0.1:5173');
if (!['http:', 'https:'].includes(target.protocol) || !['127.0.0.1','localhost','[::1]'].includes(target.hostname) || target.username || target.password || target.pathname !== '/' || target.search || target.hash) throw Error('Only loopback origin URLs (no path, credentials, query, fragment) are allowed');
if (mode === 'baseline' && (!options['--approve-baseline'] || !options['--approved-by']?.trim())) throw Error('Baseline operation requires --approve-baseline AND --approved-by <name/identifier>');
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const fromVisual = file => path.relative(visual, file).replaceAll('\\','/');
const git = (...args) => {
  const proc = spawnSync('git', args, { cwd: repo, encoding:'utf8', timeout: 12000 });
  return proc.status === 0 ? proc.stdout.trim() : null;
};
const files = fs.readdirSync(path.join(visual,'tests')).filter(n=>n.endsWith('.spec.mjs'));
const scenarioData = JSON.parse(fs.readFileSync(path.join(visual,'scenarios.json'),'utf8'));
const scenarios = scenarioData.routes;
if (!Array.isArray(scenarios) || !scenarios.length) throw Error('scenarios.json missing routes');
const identifiers = new Set();
for (const route of scenarios) {
 if (!route || !/^[a-z0-9][a-z0-9_-]{0,50}$/.test(route.id) || identifiers.has(route.id) || !route.path?.startsWith('/') || route.path.startsWith('//') || route.path.includes('\\') || typeof route.readySelector !== 'string') throw Error('Unsafe route definition');
 identifiers.add(route.id);
}
const configFiles = ['runner.mjs','verify-run.mjs','playwright.config.mjs','scenarios.json','tests/visual.spec.mjs','package.json'];
const configuration = configFiles.map(p => ({file:p, sha256:hash(path.join(visual,p))}));
const approvedFile = path.join(visual,'baseline-approval.json');
let baselines = [];
if (mode === 'compare') {
 if (!fs.existsSync(approvedFile)) throw Error('BLOCKED: baseline-approval.json missing; no implicit bootstrap');
 const approval = JSON.parse(fs.readFileSync(approvedFile,'utf8'));
 if (!approval.approvedBy || !Array.isArray(approval.baselines) || approval.baselines.length !== scenarios.length * 2) throw Error('BLOCKED: incomplete baseline approval');
 baselines = approval.baselines;
 for (const item of baselines) {
  const resolved = path.resolve(visual, item.file);
  if (!resolved.startsWith(visual + path.sep) || !fs.existsSync(resolved) || hash(resolved) !== item.sha256) throw Error(`BLOCKED: baseline modified/missing ${item.file}`);
 }
}
const cli = path.join(visual,'node_modules/@playwright/test/cli.js');
const isInstalled = fs.existsSync(cli);
const runId = new Date().toISOString().replace(/[-:.]/g,'').replace('Z','Z')+'-'+randomBytes(4).toString('hex');
const runDir = path.join(evidenceRoot,runId);
const packageJson = JSON.parse(fs.readFileSync(path.join(visual,'package.json'),'utf8'));
const context = {
  schema: 'bago.visual.run/v1', runId, dateUTC:new Date().toISOString(), repoRoot:repo,
  gitHead:git('rev-parse','HEAD'), branch:git('branch','--show-current'),
  dirty: (git('status','--porcelain') || '') !== '', mode, baseURL:target.origin,
  platform:process.platform, arch:process.arch, node:process.version,
  playwrightPinned:packageJson.devDependencies['@playwright/test'],
  baselines, baselineApproval: mode==='compare' ? {file:'baseline-approval.json',sha256:hash(approvedFile)} : null,
  scenarios:scenarios.map(x=>({id:x.id,path:x.path})), projects:['desktop-chromium','mobile-chromium'],
  configuration, noProductionRequests:true, playwrightPresent:isInstalled, evidenceDirectory:runDir,
  scope:'browser smoke + visual checks only; NOT full backend verification'
};
if (options['--dry-run']) {
 console.log(JSON.stringify({status:'DRY_RUN',repo,mode,target:target.origin,playwrightPresent:isInstalled,scenarios,configuration},null,2));
 process.exit(0);
}
fs.mkdirSync(path.join(runDir,'artifacts'),{recursive:true});
fs.writeFileSync(path.join(runDir,'run-context.json'),JSON.stringify(context,null,2)+'\n');
const result = {status:'NOT_RUN', exitCode:null, mode, reason:null};
if (!isInstalled) {
 result.reason='DEPENDENCY_MISSING: cd .gabo/frontend-pack/visual && npm install && npx playwright install chromium';
 result.exitCode=2;
} else {
 const env = { ...process.env, BAGO_PW_MODE:mode, BAGO_PW_BASE_URL:target.origin,
   BAGO_PW_EVIDENCE_DIR:runDir, BAGO_PW_APPROVED:mode==='baseline'?'true':'false' };
 const p=spawnSync(process.execPath,[cli,'test','--config',path.join(visual,'playwright.config.mjs')],{
   cwd:visual, env, encoding:'utf8', maxBuffer:6*1024*1024, timeout:180000
 });
 fs.writeFileSync(path.join(runDir,'runner-log.txt'), (p.stdout || '')+'\n--- STDERR ---\n'+(p.stderr || ''));
 result.exitCode=Number.isInteger(p.status)?p.status:1;
 result.reason=p.error?.message || (p.signal?`Signal ${p.signal}`:null);
 result.status=result.exitCode===0 ? (mode==='compare'?'EXECUTED_COMPARE_PASS_CANDIDATE':mode==='baseline'?'BASELINE_CREATED_NOT_VERIFIED':'CAPTURED_NOT_VERIFIED') : 'EXECUTED_FAIL';
 if (result.exitCode===0 && mode==='baseline') {
   const folder = path.join(visual,'tests/visual.spec.mjs-snapshots');
   const images = fs.existsSync(folder)?fs.readdirSync(folder).filter(x=>x.endsWith('.png')):[];
   if (images.length!==scenarios.length*2) {
    result.status='EXECUTED_FAIL';result.exitCode=1;result.reason='Baseline image count does not match expected scenarios';
   } else {
    const approval = {schema:'bago.visual.baseline-approval/v1', approvedBy:options['--approved-by'], approvedAt:new Date().toISOString(), gitHead:context.gitHead,
      baselines:images.sort().map(f=>({file:fromVisual(path.join(folder,f)), sha256:hash(path.join(folder,f))}))};
    fs.writeFileSync(approvedFile,JSON.stringify(approval,null,2)+'\n');
   }
 }
}
fs.writeFileSync(path.join(runDir,'result.json'),JSON.stringify(result,null,2)+'\n');
function walk(dir){let list=[]; for(const item of fs.readdirSync(dir,{withFileTypes:true})){
 const f=path.join(dir,item.name);if(item.isDirectory())list.push(...walk(f));else if(item.isFile())list.push(f);
 }return list;}
const manifest = {
  schema:'bago.visual.sha-manifest/v1', runId, generatedAt:new Date().toISOString(),
  files:walk(runDir).filter(f=>!f.endsWith('/manifest.json')).map(f=>({file:path.relative(runDir,f).replaceAll('\\','/'),sha256:hash(f)})),
  configuration,
  baselines:mode==='compare'?baselines:[],
  baselineApproval:context.baselineApproval
};
fs.writeFileSync(path.join(runDir,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({runDir,status:result.status,exitCode:result.exitCode,gitHead:context.gitHead},null,2));
process.exit(result.exitCode === 0 ? 0 : 1);
