# BAGO visual harness v1.1.0

Requiere Node.js >= 20.11, npm y un proyecto Git con frontend local ya iniciado. No toca package.json de la app.

Desde raíz del proyecto (`Windows / PowerShell`):

```powershell
cd .gabo/frontend-pack/visual
npm install
npx playwright install chromium
cd ../../..
node .gabo/frontend-pack/visual/runner.mjs --dry-run --mode capture --url http://127.0.0.1:5173
node .gabo/frontend-pack/visual/runner.mjs --mode capture --url http://127.0.0.1:5173
```

`npm install` descarga dependencias y genera package-lock.json en el directorio del harness, no en el de la app. Una vez creado lockfile, usar `npm ci` para instalaciones posteriores. La versión declarada de Playwright es exacta; nunca actualizarla implícitamente durante una auditoría.

Baseline: solo bajo permiso explícito del propietario, desde raíz:

```powershell
node .gabo/frontend-pack/visual/runner.mjs --mode baseline --approve-baseline --approved-by "identificador-del-aprobador" --url http://127.0.0.1:5173
```

Para comparar **sin cambiar baseline**:

```powershell
node .gabo/frontend-pack/visual/runner.mjs --mode compare --url http://127.0.0.1:5173
node .gabo/frontend-pack/visual/verify-run.mjs --run ".gabo/evidence/frontend-visual/<ID_RUN>" --repo .
```

Los resultados y capturas quedan en `.gabo/evidence/frontend-visual/<ID_RUN>`. La salida del runner muestra el ID real. `verify-run.mjs` por defecto **solo lee** y no genera archivos; para persistir un veredicto usar `--output .gabo/evidence/frontend-visual/verdicts/<ID_RUN>.json`. Nunca persistirlo dentro del propio run: invalidaría el manifiesto.

**Estados:** `CAPTURED_NOT_VERIFIED` = captura, no pasa comparación; `BASELINE_CREATED_NOT_VERIFIED` = referencia preparada, pendiente de revisión; `EXECUTED_COMPARE_PASS_CANDIDATE` = candidato a PASS hasta ejecutar verificador independiente. Un `PASS` del script no acredita autorización backend, seguridad o UX subjetiva.

**Límites:** solo loopback, rutas de `scenarios.json` sin clicks, Chromium headless, carga/consola/HTTP 5xx/overflow/nombres accesibles básicos y screenshot pixel. Requiere baseline aprobada para PASS. La comparación es sensible al entorno (SO, fuentes, revisión de navegador). Si faltan browser binaries o dependencias, reporta NOT_RUN/FAIL, no simula éxito.
