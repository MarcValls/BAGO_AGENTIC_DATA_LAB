# VERIFICATION_MATRIX — gates según alcance

| Gate | Evidencia requerida | Responsable | PASS |
|---|---|---|---|
| Contract and ownership | Trace real + propietarios + canon del repo | UI state tracer / verifier | Sin UNKNOWN material |
| Scope/diff | Archivos modificados y causa, cambios ajenos preservados | Engineer / verifier | Sin drift |
| Build/types | Comandos reales del proyecto y logs + exit code | Engineer | Exit 0 |
| Tests functional/API | Pruebas específicas + resultado | Engineer | Exit 0, sin omisiones críticas |
| Visual capture | PNG de 2 viewports + contexto SHA | Visual operator | Solo CAPTURED, **no** regresión aprobada |
| Visual compare | Referencia previa aprobada + `toHaveScreenshot` en ambos viewports | Visual operator | Todos los asserts pasan; sin missing baselines |
| Browser hygiene | pageerrors/console/server 5xx/overflow/accessible names | Visual operator | Cero incumplimientos |
| Provenance | Manifest hash + Git HEAD + data freshness | Independent evidence checker | Resultado PASS, sin tamper |
| Independent review | Diff + report real + límites + P0/P1/P2 | Frontend verifier | PASS/FAIL/BLOCKED argumentado |

Si algún gate requerido no se ejecuta: `NOT_RUN` / `BLOCKED`, nunca inferir PASS. Capturas no prueban contraste, UX ni accesibilidad exhaustiva. En sitios dinámicos definir máscaras y tolerancias solo con justificación explícita.
