# CODEX_COMPATIBILITY — referencia comprobada el 2026-10-12

De la documentación oficial Codex:
- Subagentes por repo `.codex/agents/<name>.toml`, requeridos `name`, `description`, `developer_instructions`; `sandbox_mode` disponible. Archivo por agente.
- Skills por repo `.agents/skills/<name>/SKILL.md` con frontmatter YAML `name`, `description`.
- `agents.enabled` por defecto true en releases actuales; sin edición de config global. El usuario puede fijar `[agents] max_concurrent_threads_per_session = 3` si lo desea.
- Los modelos de los TOML originales `gpt-5.6-terra`/`gpt-5.6-sol` NO SE GARANTIZAN en tu cuenta; instalados heredan el modelo del agente principal. En la referencia original `max` solo es válido en modelos compatibles.
- `sandbox_mode=read-only` es una restricción configurada, pero los permisos efectivos dependen del modo activo del padre y de overrides de runtime. No es un límite de seguridad del sistema operativo independiente del runtime.
- GitHub Copilot conserva roles `.github/agents/*.agent.md` y la skill compartida `.agents/skills`. Disponibilidad de tool IDs/harness se comprueba en VS Code real.

Verificación LOCAL PENDIENTE: ejecutar `codex --version`, `codex` desde el repositorio, invocar `$bago-frontend-engineering`, delegar `bago_ui_state_tracer` y comprobar los permisos reales. Node 20+ y Chromium instalable. No afirmamos haberlo ejecutado en tu Windows.

Referencias: https://learn.chatgpt.com/docs/agent-configuration/subagents ; https://learn.chatgpt.com/docs/build-skills ; https://playwright.dev/docs/test-snapshots ; https://code.visualstudio.com/docs/agent-customization/custom-agents
