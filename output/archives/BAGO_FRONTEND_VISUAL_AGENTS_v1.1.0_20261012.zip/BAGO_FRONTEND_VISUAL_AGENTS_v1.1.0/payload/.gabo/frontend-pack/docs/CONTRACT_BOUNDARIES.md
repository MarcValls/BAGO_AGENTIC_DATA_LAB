# CONTRACT_BOUNDARIES

Documento guía sin evidencia del repositorio: `UNRESOLVED` hasta lectura real.

- React/TypeScript UI → cliente HTTP/WS: comprobar contrato, validación, retry, cancelación y errores, NO inventar endpoint.
- Cliente → backend: identificar ruta real y dueño de política/autorización. Backend mantiene autoridad de ejecución y permisos.
- Frontend → Electron (si existe): delimitar IPC, preload, permisos y no exponer primitivas privilegiadas.
- Estado UI → persistencia: enumerar claves y riesgo de secretos. Evitar almacenamiento de credenciales y duplicados.
- BAGO histórico vs BAGO5: no suponer que este pack implica integración con BAGO5 ni canon común. Contexto del proyecto destino prevalece.

Handoff si la reparación requiere modificar contrato/authority externo: síntoma, fuente, enlace probado, archivo responsable, evidencia, riesgo y propuesta, marcado BLOCKED frontend.
