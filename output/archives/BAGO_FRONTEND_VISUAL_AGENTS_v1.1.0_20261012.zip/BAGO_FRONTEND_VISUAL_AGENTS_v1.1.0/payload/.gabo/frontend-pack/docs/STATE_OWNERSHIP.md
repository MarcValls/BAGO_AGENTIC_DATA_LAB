# STATE_OWNERSHIP — plantilla operativa, NO canon de BAGO

Estado inicial: `UNTRACED`. Fijar owners solo después de inspeccionar el repositorio y pruebas.

| Estado / dato | Owner canónico comprobado | Lectores | Escritores | Persistencia | Reconciliación | Contrato frontera | Evidencia |
|---|---|---|---|---|---|---|---|
| Feature solicitada | UNRESOLVED | UNRESOLVED | UNRESOLVED | UNRESOLVED | UNRESOLVED | UNRESOLVED | NOT_RUN |

Invariantes de ingeniería (principios del pack, no hallazgos del repo): (1) la UI no concede permisos ni crea autoridad backend; (2) no duplicar estado, router ni cliente API si existe uno canónico; (3) no persistir tokens/credenciales; (4) modelar loading/error/blocked/empty de forma explícita; (5) tracear la fuente de verdad y evitar cierres stale/race; (6) frontend/Electron/backend cruzan frontera documentada; (7) cada cambio preserva invariantes existentes verificadas.
