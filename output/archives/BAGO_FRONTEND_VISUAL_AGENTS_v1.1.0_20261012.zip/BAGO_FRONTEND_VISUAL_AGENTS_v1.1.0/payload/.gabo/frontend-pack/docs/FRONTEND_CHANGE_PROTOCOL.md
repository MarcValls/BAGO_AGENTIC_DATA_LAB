# FRONTEND_CHANGE_PROTOCOL v1.1.0

## Autoridad y alcance

El canon real del repositorio gana sobre este documento. No modificar canon para justificar el código. El paquete no inspecciona tu proyecto automáticamente.

## Secuencia (obligatoria)

0. Freeze observacional: registrar ruta absoluta del repo, Git HEAD, branch, worktree status, entorno y alcance aprobado. No modificar archivos ajenos.
1. READ: instrucciones del repo, stack real, UI_SURFACE_MAP, STATE_OWNERSHIP, contratos API, eventos/handlers implicados.
2. TRACE: acción → handler → componente → estado local/global/persistido → cliente API → endpoint → backend authority → response/error → reconciliación → render → test.
3. AUDIT: hallazgos P0/P1/P2 separados de inferencias y riesgos; evidencia `archivo:línea`, comando observado, entorno y reproducción.
4. PATCH: implementación mínima solo frontend, sin refactor lateral; cambios backend o de seguridad generan handoff explícito.
5. GATES: build/typecheck/test específicos disponibles; `NOT_RUN` para los que no están. Browser capture antes de visual compare. Baselines solo con autorización.
6. VERIFY: revisor distinto al implementador; inspecciona diff real, evidencia fresca y contratos. `PASS`, `FAIL` o `BLOCKED`.
7. PROMOTION: `VERIFIED` no equivale a `VALIDATED`; declarar promoción solo con autoridad explícita del responsable.

Prohibido: inventar pruebas, enmascarar fallos, modificar secretos, realizar commit/push/merge/releases sin autorización, aceptar snapshot nuevo como éxito automático, concluir backend funcional desde una llamada UI.

Receipts mínimos: task_id, fecha UTC, auditor/verificador, repo_root, head SHA, worktree_dirty, scope, comando, exit_code, artifacts, SHA256, PASS/FAIL/BLOCKED, NOT_RUN y limitaciones.
