# UI_SURFACE_MAP — ficha de descubrimiento, NO inventario canónico

Estado: `UNTRACED`. Creado por el pack, no inspeccionado contra el código real. No afirmar existencia de rutas o componentes hasta su lectura.

| Superficie | Entrada/acción | Componente/archivo:línea | Owner de navegación | API/WS/Electron | Canon verificado | Evidencia | Estado |
|---|---|---|---|---|---|---|---|
| Root/shell (pendiente) | UNTRACED | UNTRACED | UNRESOLVED | UNRESOLVED | UNRESOLVED | NOT_RUN | BLOCKED |

Procedimiento: localizar app entry, router/sidebar, panel/drawer y handlers por búsqueda estática; seguir imports, providers, app state, transporte y reconciliación. Registrar nombres y líneas reales. Marcadores: VERIFIED_PATH, PARTIAL_TRACE, N/A, UNRESOLVED. No resolver con suposiciones ni dar por funcional una UI solo porque renderiza.
