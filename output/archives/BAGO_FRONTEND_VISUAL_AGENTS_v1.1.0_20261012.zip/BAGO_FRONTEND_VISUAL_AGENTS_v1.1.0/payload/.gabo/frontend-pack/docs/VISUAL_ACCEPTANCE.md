# VISUAL_ACCEPTANCE — política de prueba

Por defecto: servidor localhost ya iniciado, ruta `/`, Chromium headless, 1440×900 desktop y 390×844 mobile, screenshot PNG completa de la ventana, CSS animations deshabilitadas. El test comprueba carga, consola/page errors, HTTP >=500, nombres accesibles elementales (buttons/images/inputs) y overflow horizontal. Bloquea solicitudes externas no-loopback.

Modos: `capture` genera evidencia sin comparar; `baseline` escribe/actualiza referencias SOLO si el operador pasa `--approve-baseline` con autorización explícita del usuario; `compare` exige baselines y falla si faltan (no autocrea). Baseline no es evaluación independiente.

La estabilidad de pixels depende de OS, navegador, fuentes, hora, datos y estado. Compare solo en el mismo entorno reproducible, con fixtures controlados, o configure exclusiones fundadas tras inspeccionar la UI. No normalizar fallos creando nueva referencia sin revisar el diff de imágenes. Browser executable debe estar instalado.

Scenarios: `.gabo/frontend-pack/visual/scenarios.json` define nombres y rutas RELATIVAS dentro del servidor. Nada de clicks mutadores, login, credenciales, scripts arbitrarios ni endpoints externos. Los tests no son una suite de negocio completa.

Resultados: `.gabo/evidence/frontend-visual/<run_id>/` incluye `run-context.json`, `playwright-report.json`, `artifacts/` y `manifest.json` (SHA256). Comprobación determinista `verify-run.mjs --run ... --repo <ruta>` crea verdict separado solo al invocarse con --output; el rol verificador sigue siendo de solo lectura.
