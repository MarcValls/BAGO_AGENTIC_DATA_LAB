# REPORT_SCHEMA — resultado único verificable

Identificador: `CRIT-BAGO-UI-<YYYYMMDD>-<id>`
Autor: identificador del agente o revisión humana (no inventar identidad)
Fecha-hora UTC: ISO-8601
Repo / branch / Git HEAD / worktree_dirty: valores observados
Scope solicitado / archivos modificados / owner / frontera: rutas verificables
Hallazgo: P0/P1/P2, FACT vs INFERENCE, causa, impacto
Traza: acción → handler → estado → transporte → endpoint → backend → render → test
Ejecución: comando literal, exit code, stdout/reporter, ambiente OS+Node+Playwright, screenshot y trace
Evidencia: manifest SHA, baseline anterior aprobado, veredicto offline y diff final
Limitaciones: NOT_RUN, UNRESOLVED, STALE y external service unverified
Conclusión: PASS/FAIL/BLOCKED + GO/NO GO justificado
Promoción: no VALIDATED por defecto; revisión independiente no sustituye autorización formal.
