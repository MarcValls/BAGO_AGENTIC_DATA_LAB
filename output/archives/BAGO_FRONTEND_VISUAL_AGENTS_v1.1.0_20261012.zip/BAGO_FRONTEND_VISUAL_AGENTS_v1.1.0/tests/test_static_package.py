"""Static conformance tests. Requires Python 3.11+, stdlib only."""
from pathlib import Path
import json
import re
import tomllib
import unittest

ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = ROOT / 'payload'


class Packaging(unittest.TestCase):
    def test_source_preservation(self):
        original = list((ROOT / 'source-originals').glob('*.toml'))
        copilot = list((ROOT / 'source-originals').glob('*.agent.md'))
        self.assertEqual((len(original), len(copilot)), (5, 5))

    def test_toml(self):
        names = []
        agents = list((PAYLOAD / '.codex/agents').glob('*.toml'))
        self.assertEqual(len(agents), 6)
        for file in agents:
            data = tomllib.loads(file.read_text('utf8'))
            names.append(data['name'])
            self.assertEqual(file.stem, data['name'])
            self.assertEqual(data['sandbox_mode'], 'workspace-write' if data['name'] in ['bago_frontend_engineer','bago_visual_test_operator'] else 'read-only')
            self.assertTrue(data['developer_instructions'])
            self.assertNotIn('model',data)
        self.assertEqual(len(set(names)), len(names))

    def test_markdown_agents(self):
        agents = list((PAYLOAD / '.github/agents').glob('*.agent.md'))
        self.assertEqual(len(agents), 6)
        for file in agents:
            text = file.read_text('utf8')
            self.assertTrue(text.startswith('---\n'))
            header = text.split('---', 2)[1]
            self.assertIn('name:', header)
            self.assertIn('tools:', header)
            self.assertIn('target: github-copilot', header)

    def test_skills(self):
        skills = list((PAYLOAD / '.agents/skills').glob('*/SKILL.md'))
        self.assertEqual(len(skills), 3)
        for file in skills:
            s = file.read_text('utf8')
            self.assertTrue(s.startswith('---\n'))
            header = s.split('---', 2)[1]
            self.assertRegex(header, r'\bname: ')
            self.assertRegex(header, r'\bdescription: ')

    def test_dependencies(self):
        docs = list((PAYLOAD / '.gabo/frontend-pack/docs').glob('*.md'))
        self.assertGreaterEqual(len(docs), 8)
        readme = PAYLOAD / '.gabo/frontend-pack/visual/README.md'
        self.assertTrue(readme.is_file())
        pkg = json.loads((PAYLOAD / '.gabo/frontend-pack/visual/package.json').read_text('utf8'))
        self.assertEqual(pkg['devDependencies']['@playwright/test'], '1.56.0')
        self.assertTrue((ROOT / 'INSTALL.ps1').is_file())


if __name__ == '__main__':
    unittest.main(verbosity=2)
