# COMPATIBILITY REPORT — 2026-10-12

Autor: ChatGPT (GPT-6); revisión de las diez definiciones suministradas.

## Fuentes

- Codex subagents: https://learn.chatgpt.com/docs/agent-configuration/subagents
- Codex skills: https://learn.chatgpt.com/docs/build-skills
- Playwright visual comparisons: https://playwright.dev/docs/test-snapshots
- VS Code agents: https://code.visualstudio.com/docs/agent-customization/custom-agents

## Resultado verificable por documentación

- PASS formato TOML: cada agente en `.codex/agents/` con `name`, `description`, `developer_instructions`; sandbox_readonly/workspace-write soportados por formato.
- PASS ubicación: skills en `.agents/skills/<name>/SKILL.md` detectadas por Codex.
- PASS formato Copilot: agentes `.github/agents/*.agent.md`; herramientas y disponibilidad exactas pueden diferir según harness.
- PASS estrategia Playwright: `expect(page).toHaveScreenshot`, baselines y report JSON están documentados; el proyecto usa `@playwright/test@1.56.0` **fijado**, Chromium independiente.
- COMPATIBILITY RISK: modelos fuentes `gpt-5.6-terra`, `gpt-5.6-sol` y esfuerzo `max` dependen del acceso real del cliente; configuración instalada hereda modelo y effort del padre, conserva fuente original para auditoría.
- COMPATIBILITY RISK: modo de permisos interactivo del hilo padre puede prevalecer sobre `sandbox_mode` de subagentes; comprobar runtime real, no confundir documentación con enforcement.
- TARGET_NOT_RUN: `codex --version`, carga real de subagentes, funcionamiento de Copilot y ejecución del navegador en PC del usuario.

## Decisión de integración

Paquete de proyecto, no plugin publicado ni MCP remoto. El harness Playwright es ejecutable mediante Node, sin inferir acceso real a navegador de Codex por sí mismo. El operador invoca comandos locales **cuando está autorizado**. No se inyectan herramientas ni se modifica config global.
