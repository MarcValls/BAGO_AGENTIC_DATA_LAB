#!/usr/bin/env python3
"""Actualiza solo la tabla técnica canónica y regenera README.md.

Uso: python apply_skills_update.py [RUTA_REPOSITORIO]
No contacta servicios, no hace commit, push ni merge.
"""
from pathlib import Path
import subprocess
import sys
import shutil

repo = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
canonical = repo/'.bago/canon/JOB_SKILL_MATRIX.md'
generator = repo/'scripts/generate_dynamic_readme.py'
source = Path(__file__).with_name('ADL_JOB_SKILL_MATRIX_TABLA.md')
if not canonical.is_file() or not generator.is_file() or not source.is_file():
    raise SystemExit('ERROR: faltan archivos. Ejecuta desde el repositorio o pasa su ruta.')
old = canonical.read_text(encoding='utf-8')
start_marker = '### Technical Skills'
end_marker = '### Soft Skills'
if old.count(start_marker)!=1 or old.count(end_marker)!=1:
    raise SystemExit('ERROR: marcadores de matriz ambiguos; no se modifica nada.')
a = old.index(start_marker)
b = old.index(end_marker,a)
old_section = old[a:b]
if '| Skill |' not in old_section:
    raise SystemExit('ERROR: tabla técnica no reconocida; no se modifica nada.')
replacement = source.read_text(encoding='utf-8').rstrip()+'\n\n'
updated = old[:a]+replacement+old[b:]
if old==updated:
    print('Tabla canónica sin cambios.')
else:
    backup = canonical.with_suffix('.md.bak')
    if backup.exists():
        raise SystemExit('ERROR: ya existe copia .bak; revisar antes de sobrescribir.')
    shutil.copy2(canonical,backup)
    canonical.write_text(updated,encoding='utf-8')
    print(f'Matriz actualizada. Respaldo: {backup.relative_to(repo)}')
print('Regenerando README desde la matriz canónica...')
r=subprocess.run([sys.executable,str(generator),'--skip-tests'],cwd=repo,check=False)
if r.returncode:
    raise SystemExit(f'ERROR: regeneración fallida ({r.returncode}); matriz cambiada, copia .bak disponible.')
r=subprocess.run([sys.executable,str(generator),'--check','--skip-tests'],cwd=repo,check=False)
if r.returncode:
    raise SystemExit(f'ERROR: deriva del README ({r.returncode}).')
print('PASS: README generado y consistente (sin ejecutar suite completa).')
print('Validación independiente pendiente: python -m pytest tests -q')
