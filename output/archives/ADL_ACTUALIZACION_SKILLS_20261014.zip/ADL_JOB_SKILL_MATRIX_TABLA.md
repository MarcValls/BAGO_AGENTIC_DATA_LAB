### Technical Skills

| Skill | Market Demand | Current Level | Target Level | First Evidence | Interview Ready |
|---|---|---|---|---|---|
| Python | Alta | ✅ Sénior | 🎯 Sénior | Backend de BAGO | ✅ Preparado |
| APIs REST | Alta | ✅ Sénior | 🎯 Sénior | FastAPI de BAGO | ✅ Preparado |
| LangGraph | Muy alta | 🟢 Implementado localmente | 🎯 Competente | StateGraph + aprobación exacta + RAG gobernado + gateway + sandbox + recibos + LocalTrace | L1 local validado; sin acreditar identidad, persistencia durable ni aislamiento del SO |
| Conceptos de LangChain | Alta | 🟡 Base práctica | 🎯 Básico | StateGraph + interrupt/resume + checkpoint en memoria | L1 validado localmente |
| Sistemas multiagente | Muy alta | 🟢 Implementación reforzada | 🎯 Competente | GovernedKnowledgeAgent + evidencias L9 | L9 validado sin integración externa real |
| Uso de herramientas | Muy alta | 🟢 Implementado | 🎯 Competente | Herramientas BAGO + recibos MCP | L5: implementación base |
| MCP | Muy alta | 🟢 Implementación base gobernada | 🎯 Competente | Adaptador MCP L5 + vídeo | L5: validación local por stdio |
| RAG | Muy alta | 🟡 Base gobernada local | 🎯 Avanzado | RAG gobernado L4 | L4 local; no acredita calidad de producción |
| Recuperación híbrida | Alta | 🟢 Implementada localmente | 🎯 Competente | L4: corpus sintético de 32 documentos, 9 consultas; Recall@1/@3 y MRR | Benchmark determinista; embeddings de producción y relevancia real pendientes |
| Embeddings | Alta | 🟢 Implementación determinista local | 🎯 Implementado | HashEmbedding + SQLiteVectorStore | L14 local; no equivale a embeddings de modelos de producción |
| Bases de datos vectoriales | Alta | 🟢 Persistencia local implementada | 🎯 Competente | SQLiteVectorStore + recarga de GovernedRAG | L14 local; servicio distribuido no acreditado |
| ETL | Alta | 🟢 Implementado localmente | 🎯 Competente | L2: ingesta a SQLite, deduplicación, recibos y prueba de solapamiento corregida | Validación local; recuperación de fallos parciales y consistencia transaccional pendientes |
| Pipelines de datos | Alta | 🟢 Pipeline documental local implementado | 🎯 Implementado | Ingesta L2 consumida por el adaptador SQLite de L4 | Sin acreditar planificación, recuperación programada ni procesamiento distribuido |
| Metadatos y ontologías | Media | 🟢 Implementado | 🎯 Competente | Esquema L3 + motor L10 | L10 local |
| RDF / SPARQL / Grafos de conocimiento | Alta | 🟢 Implementación base local | 🎯 Competente | RDF/Turtle + SPARQL + inferencia L10 | L10 local; triplestore externo no acreditado |
| Linaje de datos | Media | 🟢 Implementado | 🎯 Competente | Relaciones L3 + rutas L10 | L10 local |
| AWS | Alta | 🟢 Bedrock real acotado + plan gratuito observado | 🎯 Dominio de Bedrock | Adaptador L6 + Converse real + recibos de Free Tier | IAM de mínimo privilegio y ausencia de cargos posteriores no acreditados |
| Amazon Bedrock | Alta | 🟢 Converse real de alcance limitado | 🎯 Competente | Converse/Stream L6 + recibo de llamada real | Streaming real y evaluación de modelos pendientes |
| Bedrock Knowledge Bases | Alta | 🟡 Base sin conexión | 🎯 Competente | Retrieve/Generate L7 + citas | Evaluación real de Knowledge Bases pendiente |
| OpenMetadata | Media | 🟢 Operativo y verificado localmente | 🎯 Competente | Adaptador L8 + Docker local + recibos de linaje y calidad | Integración remota pendiente |
| IAM | Alta | 🟡 Básico | 🎯 Configurable | Configuración de mínimo privilegio L6 | Comprobación de políticas reales pendiente |
| CI/CD | Alta | 🟢 Reproducible | 🎯 Implementado | GitHub Actions + dependencias fijadas + E2E público | CI completa satisfactoria en PR #53; nuevas ejecuciones se comprueban por SHA |
| Evaluación | Muy alta | 🟢 Evaluaciones locales de gobernanza | 🎯 Framework completo | 203 casos de prueba + trazas/evidencias + escenarios L8–L15 | L15 local + CI; cifra de casos separada de pruebas totales |
| Observabilidad | Alta | 🟢 OpenTelemetry operativo localmente | 🎯 Completo | LocalTrace + OTLP/HTTP + Jaeger Docker + spans enlazados | L15 local; integración remota no acreditada |
| Ejecución segura | Muy alta | 🟢 Backend local verificado | 🎯 Implementado | Frontera de autorización BAGO + LocalRestrictedBackend + pruebas de escape | L11 local; aislamiento completo del SO no acreditado |
| Autorización | Muy alta | 🟡 Diseñada y parcialmente validada | 🎯 Implementado | Puerta fail-closed L1; límites MCP, Bedrock y sandbox probados por separado | L1: integración y alcance parcialmente acreditados |
| Auditabilidad | Alta | 🟡 Diseñada y parcialmente validada | 🎯 Implementado | Recibos de adaptadores/sandbox; L1 no inventa recibos sin gateway | L1: evidencia parcial |
| Docker / Kubernetes | Media | 🟡 Docker Compose local | 🎯 Básico | OpenMetadata Compose + healthcheck reproducible | L8 local; Kubernetes no acreditado |
