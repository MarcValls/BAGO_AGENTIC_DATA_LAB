# BAGO ADL — Actualización de la matriz de competencias

Base: README compartido por el usuario (14/10/2026), con 248/248 documentados.
Contrastado contra el código y la matriz canónica de GitHub tras el merge de PR #53
(commit `cbd78e44d7bdc33e3fde725437c768f30878f7cb`).

## Cambios acotados

- Se normalizan los 28 registros de Skills evidenciadas a español.
- Todos los niveles objetivo usan 🎯; ✅ solo para sénior declarado, 🟢 para implementación acreditada y 🟡 para nivel básico/validación parcial.
- Recuperación híbrida, ETL y pipelines se reconocen como implementados localmente, manteniendo alcance y límites en la columna Entrevista.
- Se conservan las 32 fuentes sintéticas, nueve consultas y métricas documentadas en L4; la prueba de solapamiento de L2 ya está corregida en PR #53.
- No se modifica el resto del README, métricas, fases, inventarios, diagramas, comandos, contratos ni declaración de integraciones.

## Aplicación

El README del repositorio es generado, por lo que la fuente de verdad es `.bago/canon/JOB_SKILL_MATRIX.md`.
En el repositorio clonado, con estos dos archivos en un mismo directorio:

```
python apply_skills_update.py "C:\ruta\a\BAGO_AGENTIC_DATA_LAB"
python -m pytest tests -q
```

El script copia la matriz original a `JOB_SKILL_MATRIX.md.bak`, modifica solo la tabla `### Technical Skills`,
regenera `README.md` mediante el generador existente y comprueba su consistencia sin ejecutar la suite completa.
No realiza modificaciones en GitHub ni operaciones de red.

`ADL_README_ACTUALIZADO.md` es una vista documental del README aportado, no el archivo canónico.
Si el repositorio ha cambiado desde ese snapshot, solo se debe usar la matriz canónica + el regenerador.

## CI observado

Hubo CI satisfactoria para `49d930cf` el 14/10/2026. La nueva ejecución de CI iniciada para
el merge `cbd78e44` figuraba `in_progress` en la consulta; no debe declararse éxito de ese SHA
sin una comprobación posterior de su ejecución.
