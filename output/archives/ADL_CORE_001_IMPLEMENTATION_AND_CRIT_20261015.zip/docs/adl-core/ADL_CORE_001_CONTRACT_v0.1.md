# ADL-CORE-001 — Normativo v0.1 (slice mínimo)

**Estado contractual:** CANDIDATE; no integrado ni congelado en `main`.
**Sistema:** ADL únicamente. Ningún productor concreto es supuesto.
**Baseline remoto inmovilizado por identificación:** `MarcValls/BAGO_AGENTIC_DATA_LAB`, `main`, `cbd78e44d7bdc33e3fde725437c768f30878f7cb` (2026-10-14).
**Garantía de congelación:** referencia SHA y listado de blobs, NO tag Git creado, ni checkout local completo del repositorio.

## Problema y alcance

Conservar conocimiento comprobable sobre una entidad y sus capacidades, asociar muestras de evidencia a una versión exacta y detectar degradaciones entre dos versiones sin confiar en un `PASS` declarado por el productor.

**Esta versión no ejecuta software del productor.** `bytes_equal` contrasta pares de muestras entregadas, y sólo demuestra igualdad de los bytes recibidos. La ejecución de la capacidad, autenticidad del productor, procedencia de las muestras y equivalencia conductual permanecen `NOT_RUN` / `NOT_VERIFIED`. La etiqueta `regressed_sample_checks` es una regresión de muestras, no de comportamiento de una aplicación.

## Entidades y relaciones mínimas

1. `EntityVersion(entity_id, version, kind, declared_producer, registered_at)` — clave compuesta exacta `(entity_id, version)`; `declared_producer` no está autenticado.
2. `CapabilityContract(capability_id, version, requirement, check_type)` — por ahora `check_type=bytes_equal`. Contratos distintos nunca se comparan automáticamente como equivalentes.
3. `EntityCapabilityDeclaration(entity_id, entity_version, capability_id, contract_version)` — una declaración por capacidad/versión de entidad. Registrar no verifica.
4. `Evidence(evidence_id, entity_id, entity_version, capability_id, contract_version, source_digest, output_digest, producer_claim, received_at)` — muestras originales en CAS, identidad de prueba en SQLite. La alegación del productor es dato no confiable.
5. `Evaluation(evaluation_id, evidence_id, verifier_id, verifier_version, sample_check, integrity, behavior_execution, producer_authentication, created_at, diagnostics)` — resultado añadido, no sustituye el anterior.

Ninguna entidad puede existir sin un identificador y una versión válida. Ninguna evidencia es admisible si no existe antes la declaración de capacidad de esa versión. No se cambia una entidad o contrato registrado; una modificación exige otra versión. Idempotencia permitida únicamente con contenido idéntico.

## Estados (dimensiones independientes)

- `producer_claim`: `PASS` / `FAIL` / `UNKNOWN`, **nunca autoridad**.
- `integrity`: `PASS` / `FAIL` para CAS re-hasheado.
- `sample_check`: `PASS` / `FAIL` / `ERROR` / `UNKNOWN` para igualdad de muestras.
- `behavior_execution`: siempre `NOT_RUN` (este slice no ejecuta productores).
- `producer_authentication`: siempre `NOT_VERIFIED`.
- `sample_compatibility`: `PASS` / `BLOCKED` para comparación interna de muestras.
- `behavioral_compatibility`: siempre `NOT_VERIFIED`.
- `promotion`: siempre `BLOCKED` hasta existir evaluación real del comportamiento más autorización explícita de promoción.

Ningún indicador de muestras se reetiqueta como comportamiento `VERIFIED`.

## Conservación y comparación diferencial

- Artefactos se conservan por SHA-256 en `cas/sha256/ab/<64hex>`; entrada: `bytes` con límite de 1 MiB.
- No hay API de actualización ni borrado de artefactos, evidencias o evaluaciones. Triggers SQLite rechazan `UPDATE`/`DELETE` de tablas nucleares en operaciones normales (un operador privilegiado puede eliminarlos).
- Cada evaluación hace lectura de CAS y recalcula SHA-256; los reportes de comparación también comprueban de nuevo la integridad del último conjunto de muestras.
- Si una capacidad existe en baseline pero no en candidato, estado `removed`, bloqueador.
- Si el contrato cambia de versión, estado `contract_changed`, bloqueador.
- Si el baseline pasa la prueba de muestras y candidato falla, `regressed_sample_checks`, bloqueador.
- Si faltan pruebas o integridad, `unverified`, bloqueador.
- Si ambos pasan, `preserved_sample_checks`, pero esto no valida la conducta real.
- Añadir capacidades nuevas nunca compensa eliminar ni degradar capacidades existentes.
- El historial permanece consultable incluso después de detectar corrupción; no se borra una evaluación anterior.

## Interfaces

`ADLCore(root)` expone `register_entity`, `register_contract`, `declare_capability`, `receive_samples`, `verify_samples`, `latest_result`, `compare_versions`. Son operaciones **de datos**, sin ejecución, shell, red, permisos ni importación del código recibido.

Secuencia de demostración:

```
python -m pytest tests/test_adl_core.py -q
python scripts/run_adl_core_demo.py --store evidence/demo_store --output evidence/demo_result.json
python scripts/verify_adl_core_independent.py --store evidence/demo_store --output evidence/independent_retest.json
python scripts/run_independent_retest.py --store evidence/demo_store --output evidence/adversarial_retest.json
```

## Responsabilidades existentes: KEEP / ADAPT / HOLD

| Fuente original en `main` | Decisión | Razón |
|---|---|---|
| `src/observability/local_trace.py` | KEEP | Traza de ejecuciones internas; no convertirla en recepción externa ni fuente de integridad criptográfica. |
| `src/evaluation/local_evals.py` | KEEP | Evaluación de invariantes de trace existentes; no reemplazar. |
| `src/evaluation/agent_lab.py` | ADAPT FUTURO | SQLite suites y runs de agentes existentes; evitar reescribir/sobrecargar esquema en MVP. |
| `src/sandbox/receipt.py` | KEEP | Recibos locales de ejecución; no usarlos como prueba de origen externo. |
| `src/observability/otel_bridge.py` | KEEP | OpenTelemetry es una proyección, no autoridad. |
| `frontend/src/contracts/decision/evidence.ts` | ADAPT FUTURO | Identidad de evidencia y relación claim-evidence sin autoproclamar procedencia. |
| `src/execution/gateway.py` | HOLD | No realizar ejecución de productores en este MVP. |
| `src/context/workspace_binding.py` | HOLD | No crear permisos de workspace al recibir datos. |

**No se modifican los archivos anteriores**; la nueva implementación vive en `src/adl_core/`, con pruebas independientes bajo `tests/`. No introduce otro LLM, proveedor, motor de autorización, interfaz o sistema de observabilidad.

## Limitaciones de seguridad explícitas

- SQLite + CAS local no ofrecen inmutabilidad ante administradores privilegiados, cambios físicos ni rollback del almacén completo.
- No hay firmas, anclaje externo, evidencias desde génesis, identidad criptográfica del productor, procedencia externa, ni validación semántica de capacidades.
- La protección de symlinks es básica; existe posible carrera TOCTOU y riesgo con hardlinks/directorios manipulados concurrentemente. No abrir este almacén sobre directorios controlados por productores adversarios.
- No se importan ZIP no confiables ni se ejecuta código arbitrario. La recepción de muestras se hace desde objetos de bytes ya proporcionados por el llamante.
- No hay API multiusuario ni control de acceso: sólo referencia local en directorio privado.
- `EvaluationStore` del ADL original no se integra todavía; mantener dominios separados hasta verificar sus invariantes.
- Sin contrato de aislamiento de SO ni permisos explícitos, ejecutar software ajeno debe permanecer `NOT_RUN`.

## Regla de conformidad

La suite positiva/negativa del slice **no certifica la aplicación ADL entera**. `GO_LIMITED` se refiere exclusivamente a equivalencia de muestras con almacenamiento íntegro. La promoción del componente evaluado sigue `BLOCKED`.
