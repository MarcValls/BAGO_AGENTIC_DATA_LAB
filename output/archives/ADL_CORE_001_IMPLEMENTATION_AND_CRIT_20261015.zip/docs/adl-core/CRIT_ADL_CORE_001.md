# CRIT-ADL-CORE-001 — Auditoría del candidato aislado

Fecha: 2026-10-15. Commit base identificado: `cbd78e44d7bdc33e3fde725437c768f30878f7cb`.

## Claim → comando → evidencia → conclusión

| Claim acotado | Comando/inspección | Evidencia | Dictamen |
|---|---|---|---|
| El candidato implementa relaciones entidad/contrato/declaración/evidencia/evaluación | Lectura de `src/adl_core/core.py` + `pytest` | `evidence/isolated_pytest.txt` | `PASS`, alcance aislado. |
| Positivos/negativos previstos, incluyendo no promoción y CAS corrupto | `python -m pytest tests/test_adl_core.py -q` | `evidence/isolated_pytest.txt` | `20 PASS`. |
| Dos versiones reciben evidencias separadas | `python scripts/run_adl_core_demo.py --store evidence/demo_store` | `evidence/demo_result.json` y `evidence/demo_store/` | `PASS` para importación y muestras; conducta `NOT_RUN`. |
| Verificador independiente reproduce comprobaciones de muestras y CAS | `python scripts/verify_adl_core_independent.py --store evidence/demo_store` | `evidence/independent_retest.json` | `GO_LIMITED` de verificación de muestras; no de sistema completo. |
| Mutaciones adversariales detectadas | `python scripts/run_independent_retest.py --store evidence/demo_store` | `evidence/adversarial_retest.json` | `4/4 PASS` (1 control positivo + 3 negativos). |
| Preservación de componentes de ADL actual | Comparación de rutas propuestas con manifiesto git de `main`; no se alteran archivos existentes | `BASELINE_FROZEN_MANIFEST.json` | `DESIGN_PASS`; no hay prueba diferencial full-ADL ejecutada. |
| Suite integrada del repositorio y Windows | No ejecutadas por falta de checkout y de entorno Windows | `NOT_RUN` | No permite cierre de auditoría. |

## Hallazgos y riesgos

- **P0 actuales del slice probado:** 0 detectados por los 20 vectores y el retest adversarial. No representa ausencia de fallos fuera de su cobertura.
- **P1-01 (gate integración):** el módulo no está instalado en `main`; no se ejecutó la suite completa de ADL tras el cambio. **OPEN**.
- **P1-02 (gate procedimiento):** protocolo de coordinación `AGENTS.md`/`teamctl` y handoffs no ejecutados sobre worktree real. **OPEN**.
- **P1-03 (gate plataforma):** retest Windows 10 / PowerShell y verificación de operación de instalador no realizados. **OPEN**.
- **P2-01:** el CAS local está sujeto a ataques de modificación privilegiada, TOCTOU y posible sustitución de directorios/hardlinks. **OPEN / scope limitation**.
- **P2-02:** `EvidenceStore` propuesto es independiente del existente `EvaluationStore` hasta validar un adaptador; no considerar integrado el registro de pruebas completo. **OPEN**.
- **P2-03:** las pruebas son comprobaciones de muestras suministradas, no reproducción de comportamiento ejecutable. **OPEN / scope limitation**.
- **P2-04:** no hay firmas ni procedencia de origen, evidencias externas o prueba de cadena append-only. **OPEN / scope limitation**.

## Dictamen final

**SLICE_LOCAL: GO_LIMITED**, para registro tipado, CAS, igualdad de muestras, persistencia y comparación de resultados de muestras bajo las condiciones declaradas.

**ADL MAIN INTEGRATION: NO_GO** (`P0 detectados=0 / P1=3 abiertos / P2=4 límites`), hasta instalar sobre base fresca, ejecutar suite completa, regenerar README desde fuentes canónicas, Windows retest y auditoría independiente integrada.

**Prohibición:** ningún `PASS` de muestras se traduce en compatibilidad funcional o capacidad real verificada. `promotion = BLOCKED` por contrato en todo este MVP.

Siguiente gate: `APPLY TO FRESH BRANCH → RE-RUN FULL CI → GENERATE README → TEAMCTL HANDOFFS → WINDOWS RETEST → INDEPENDENT INTEGRATION AUDIT → CRIT-ADL-CORE-001-RETEST-1`.
