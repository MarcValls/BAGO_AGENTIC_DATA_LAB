# Read-only preflight by default. Use -Apply only after reviewing the candidate.
param(
    [Parameter(Mandatory = $true)][string]$RepositoryPath,
    [switch]$Apply
)
$ErrorActionPreference = 'Stop'
$Expected = 'cbd78e44d7bdc33e3fde725437c768f30878f7cb'
$RepositoryPath = (Resolve-Path -LiteralPath $RepositoryPath).Path
$Head = ((& git -C $RepositoryPath rev-parse HEAD) -join '').Trim()
if ($LASTEXITCODE -ne 0) { throw 'Cannot read Git HEAD.' }
if ($Head -ne $Expected) { throw "Baseline mismatch: $Head. Expected: $Expected. No files copied." }
$Changes = @(& git -C $RepositoryPath status --porcelain)
if ($LASTEXITCODE -ne 0 -or $Changes.Count -gt 0) { throw 'Repository worktree not clean. No files copied.' }
$Files = @(
    'src/adl_core/__init__.py',
    'src/adl_core/core.py',
    'tests/test_adl_core.py',
    'scripts/run_adl_core_demo.py',
    'scripts/verify_adl_core_independent.py',
    'scripts/run_independent_retest.py',
    'docs/adl-core/ADL_CORE_001_CONTRACT_v0.1.md',
    'docs/adl-core/BASELINE_FROZEN_MANIFEST.json',
    'docs/adl-core/CONFORMANCE_VECTORS.json',
    'docs/adl-core/CRIT_ADL_CORE_001.md'
)
# Complete preflight before the first write. Existing files are never overwritten.
foreach ($Relative in $Files) {
    $Source = Join-Path $PSScriptRoot $Relative
    $Destination = Join-Path $RepositoryPath $Relative
    if (!(Test-Path -LiteralPath $Source -PathType Leaf)) { throw "Missing package file: $Relative" }
    if (Test-Path -LiteralPath $Destination) { throw "Destination already exists: $Relative" }
}
if (-not $Apply) {
    Write-Output "PREPARED: $($Files.Count) new files; source and destination checked; no changes made."
    Write-Output 'To install: .\INSTALL_ADL_CORE_001.ps1 -RepositoryPath <path> -Apply'
    exit 0
}
foreach ($Relative in $Files) {
    $Source = Join-Path $PSScriptRoot $Relative
    $Destination = Join-Path $RepositoryPath $Relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $Destination) -Force | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Destination -ErrorAction Stop
}
Write-Output 'FILES COPIED (NOT VERIFIED): Run: python -m pytest tests/test_adl_core.py -q'
Write-Output 'Next: python scripts/run_adl_core_demo.py --store evidence/demo_store'
Write-Output 'Next: python scripts/run_independent_retest.py --store evidence/demo_store'
Write-Output 'Next: perform full ADL CI, teamctl mission handoffs, Windows retest, README generation.'
