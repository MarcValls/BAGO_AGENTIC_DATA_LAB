"""Independent ADL-CORE-001 inspector: uses only Python standard library.

This file MUST NOT import adl_core or call its own verifier. Reads SQLite/CAS
through separate code paths and validates each retained sample evaluation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
from pathlib import Path

_HEX = re.compile(r"^[0-9a-f]{64}$")


def independent_review(store: Path) -> dict:
    problems = []
    checked = 0
    dbpath = store / "adl_core.sqlite3"
    if not dbpath.is_file():
        return {"verdict": "NO_GO", "checked": 0, "issues": ["database_missing"]}
    db = sqlite3.connect(f"file:{dbpath.resolve()}?mode=ro", uri=True)
    db.row_factory = sqlite3.Row
    try:
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            problems.append("sqlite_integrity_failed")
        links = db.execute("""
            SELECT ev.*, en.kind, de.contract_version AS referenced_contract,
                   c.check_type FROM evidence ev
            LEFT JOIN entities en ON en.entity_id=ev.entity_id AND en.version=ev.entity_version
            LEFT JOIN declarations de ON de.entity_id=ev.entity_id AND de.entity_version=ev.entity_version
                AND de.capability_id=ev.capability_id
            LEFT JOIN contracts c ON c.capability_id=ev.capability_id AND c.version=ev.contract_version
        """).fetchall()
        for ev in links:
            checked += 1
            eid = ev["evidence_id"]
            if ev["kind"] is None or ev["referenced_contract"] != ev["contract_version"] or ev["check_type"] != "bytes_equal":
                problems.append(f"{eid}:unresolved_or_conflicting_contract")
            samples: list[bytes | None] = []
            for field in ("source_digest", "output_digest"):
                digest = ev[field]
                if not isinstance(digest, str) or not _HEX.fullmatch(digest):
                    problems.append(f"{eid}:{field}:invalid_digest")
                    samples.append(None)
                    continue
                p = store / "cas" / "sha256" / digest[:2] / digest
                if p.parent.is_symlink() or p.is_symlink() or not p.is_file() or p.stat().st_size > 1024 * 1024:
                    problems.append(f"{eid}:{field}:cas_missing_or_unsafe")
                    samples.append(None)
                    continue
                data = p.read_bytes()
                if hashlib.sha256(data).hexdigest() != digest:
                    problems.append(f"{eid}:{field}:CAS_TAMPER_DETECTED")
                    samples.append(None)
                else:
                    samples.append(data)
            expected = "ERROR" if any(s is None for s in samples) else "PASS" if samples[0] == samples[1] else "FAIL"
            evals = db.execute("SELECT * FROM evaluations WHERE evidence_id=? ORDER BY rowid", (eid,)).fetchall()
            if not evals:
                problems.append(f"{eid}:no_evaluation")
            for ver in evals:
                if ver["behavior_execution"] != "NOT_RUN" or ver["producer_authentication"] != "NOT_VERIFIED":
                    problems.append(f"{eid}:unsupported_promotion")
                if ver["integrity"] not in ("PASS", "FAIL") or ver["sample_check"] not in ("PASS", "FAIL", "ERROR", "UNKNOWN"):
                    problems.append(f"{eid}:invalid_evaluation_status")
                if expected != "ERROR" and (ver["sample_check"] != expected or ver["integrity"] != "PASS"):
                    problems.append(f"{eid}:result_disagrees_with_artifacts")
                # If source is now corrupt, an older PASS may be historical and cannot be
                # retroactively blamed for its old result. Integrity issue above blocks GO.
    finally:
        db.close()
    return {
        "verifier": "independent-stdlib-0.1.0",
        "verdict": "GO_LIMITED" if not problems and checked > 0 else "NO_GO",
        "checked": checked,
        "issues": problems,
        "scope": "cross-check SQLite references and producer-supplied bytes; no runtime execution or origin authentication",
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--store", type=Path, required=True)
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    result = independent_review(args.store)
    out = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(out + "\n", encoding="utf-8")
    print(out)
    raise SystemExit(0 if result["verdict"] == "GO_LIMITED" else 1)
