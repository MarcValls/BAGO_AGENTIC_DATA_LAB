"""MVP reproducible: data samples only, not code execution."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from adl_core import ADLCore


def demo(path: Path) -> dict:
    # Never append duplicate fixtures to a previous reference execution.
    if path.exists() and any(path.iterdir()):
        raise RuntimeError("Demo store must be a new, empty directory; never overwrite history")
    core = ADLCore(path)
    core.register_contract("file_preservation", "1.0", requirement="Input and output sample bytes remain identical")
    for version, output in (("1.0", b"original"), ("1.1", b"changed")):
        core.register_entity("FileManager", version, kind="library", declared_producer="sample-producer-UNAUTHENTICATED")
        core.declare_capability("FileManager", version, "file_preservation", "1.0")
        evidence = core.receive_samples("FileManager", version, "file_preservation",
                                        source=b"original", output=output, producer_claim="PASS")
        core.verify_samples(evidence)
    return {
        "profile": "ADL-CORE-001-VERTICAL-SLICE",
        "store_root": str(path.resolve()),
        "scope": "consistency_of_submitted_bytes_only",
        "independent_verification": "NOT_RUN",
        "comparison": core.compare_versions("FileManager", "1.0", "1.1"),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = demo(args.store)
    report = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report + "\n", encoding="utf-8")
    print(report)
