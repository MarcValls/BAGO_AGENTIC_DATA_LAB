"""Independent adversarial driver: changes stored bytes/records without core imports."""
from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
from pathlib import Path
from verify_adl_core_independent import independent_review


def run(source: Path) -> dict:
    positive = independent_review(source)
    with tempfile.TemporaryDirectory(prefix="adl-core-crit-") as temp:
        temp = Path(temp)
        damaged = temp / "damaged_cas"
        shutil.copytree(source, damaged)
        with sqlite3.connect(damaged / "adl_core.sqlite3") as db:
            digest = db.execute("SELECT source_digest FROM evidence ORDER BY rowid LIMIT 1").fetchone()[0]
        (damaged / "cas" / "sha256" / digest[:2] / digest).write_bytes(b"CORRUPTED BY INDEPENDENT RETEST")
        tamper = independent_review(damaged)

        fabricated = temp / "fabricated_result"
        shutil.copytree(source, fabricated)
        with sqlite3.connect(fabricated / "adl_core.sqlite3") as db:
            db.execute("DROP TRIGGER IF EXISTS evaluation_no_update")
            db.execute("UPDATE evaluations SET sample_check='PASS' WHERE sample_check='FAIL'")
        forged = independent_review(fabricated)

        unjustified = temp / "unjustified_promotion"
        shutil.copytree(source, unjustified)
        with sqlite3.connect(unjustified / "adl_core.sqlite3") as db:
            db.execute("DROP TRIGGER IF EXISTS evaluation_no_update")
            db.execute("UPDATE evaluations SET behavior_execution='PASS'")
        promoted = independent_review(unjustified)

    checks = {
        "unaltered_positive": positive["verdict"] == "GO_LIMITED" and positive["checked"] == 2,
        "damaged_content_detected": tamper["verdict"] == "NO_GO" and any("CAS_TAMPER_DETECTED" in s for s in tamper["issues"]),
        "forged_pass_detected": forged["verdict"] == "NO_GO" and any("result_disagrees" in s for s in forged["issues"]),
        "unsupported_promotion_detected": promoted["verdict"] == "NO_GO" and any("unsupported_promotion" in s for s in promoted["issues"]),
    }
    return {"verdict": "PASS" if all(checks.values()) else "FAIL", "checks": checks,
            "positive": positive, "tampered_artifact": tamper, "forged_evaluation": forged,
            "unsupported_promotion": promoted,
            "independent_implementation": True,
            "limitations": ["did_not_execute_producer_code", "full_ADL_CI_NOT_RUN", "Windows_retest_NOT_RUN"]}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.store)
    out = json.dumps(result, sort_keys=True, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(out + "\n", encoding="utf-8")
    print(out)
    raise SystemExit(0 if result["verdict"] == "PASS" else 1)
