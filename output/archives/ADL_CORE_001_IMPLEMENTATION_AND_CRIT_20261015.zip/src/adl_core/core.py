"""Minimal ADL domain core: entity -> capability -> evidence -> test -> comparison.

No executors, no imports of producer code, no provider calls and no authority claims.
The input/output byte samples are submitted by a producer and do NOT establish
that a real software execution produced either sample.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import uuid
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
from typing import Any

_ID = re.compile(r"^[A-Za-z][A-Za-z0-9_.:-]{1,79}$")
_VERSION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$")
_HASH = re.compile(r"^[0-9a-f]{64}$")
_MAX_ARTIFACT_BYTES = 1024 * 1024


class ContractError(ValueError):
    """Bad contract, invalid reference, or attempted mutation of a frozen record."""


class IntegrityError(RuntimeError):
    """A retained content-addressed artifact has lost integrity."""


def _text(name: str, value: str, rule: re.Pattern[str] = _ID) -> str:
    if not isinstance(value, str) or not rule.fullmatch(value):
        raise ContractError(f"Invalid {name}")
    return value


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class ADLCore:
    """Data-only, workspace-local registry. Distinct from ADL's existing EvaluationStore.

    The database is a metadata index. CAS bytes are persisted once and rechecked
    before every evaluation; immutable here means no app-level update API, not
    resistance to privileged filesystem/database attackers.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.cas = self.root / "cas" / "sha256"
        self.cas.mkdir(parents=True, exist_ok=True)
        self.database = self.root / "adl_core.sqlite3"
        with self._connection() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS entities (
                entity_id TEXT NOT NULL, version TEXT NOT NULL, kind TEXT NOT NULL,
                declared_producer TEXT NOT NULL, registered_at TEXT NOT NULL,
                PRIMARY KEY (entity_id, version)
            );
            CREATE TABLE IF NOT EXISTS contracts (
                capability_id TEXT NOT NULL, version TEXT NOT NULL, check_type TEXT NOT NULL,
                requirement TEXT NOT NULL, PRIMARY KEY (capability_id, version)
            );
            CREATE TABLE IF NOT EXISTS declarations (
                entity_id TEXT NOT NULL, entity_version TEXT NOT NULL,
                capability_id TEXT NOT NULL, contract_version TEXT NOT NULL,
                PRIMARY KEY (entity_id, entity_version, capability_id),
                FOREIGN KEY (entity_id, entity_version) REFERENCES entities(entity_id, version),
                FOREIGN KEY (capability_id, contract_version) REFERENCES contracts(capability_id, version)
            );
            CREATE TABLE IF NOT EXISTS evidence (
                evidence_id TEXT PRIMARY KEY, entity_id TEXT NOT NULL, entity_version TEXT NOT NULL,
                capability_id TEXT NOT NULL, contract_version TEXT NOT NULL,
                source_digest TEXT NOT NULL, output_digest TEXT NOT NULL,
                producer_claim TEXT NOT NULL, received_at TEXT NOT NULL,
                FOREIGN KEY (entity_id, entity_version, capability_id)
                    REFERENCES declarations(entity_id, entity_version, capability_id)
            );
            CREATE TABLE IF NOT EXISTS evaluations (
                evaluation_id TEXT PRIMARY KEY, evidence_id TEXT NOT NULL,
                verifier_id TEXT NOT NULL, verifier_version TEXT NOT NULL,
                sample_check TEXT NOT NULL, integrity TEXT NOT NULL,
                behavior_execution TEXT NOT NULL, producer_authentication TEXT NOT NULL,
                created_at TEXT NOT NULL, diagnostics TEXT NOT NULL,
                FOREIGN KEY (evidence_id) REFERENCES evidence(evidence_id)
            );
            CREATE INDEX IF NOT EXISTS idx_evidence_target
                ON evidence(entity_id, entity_version, capability_id, received_at);
            CREATE INDEX IF NOT EXISTS idx_evaluations_evidence
                ON evaluations(evidence_id, created_at);
            CREATE TRIGGER IF NOT EXISTS entity_no_update BEFORE UPDATE ON entities
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS entity_no_delete BEFORE DELETE ON entities
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS contract_no_update BEFORE UPDATE ON contracts
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS contract_no_delete BEFORE DELETE ON contracts
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS declaration_no_update BEFORE UPDATE ON declarations
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS declaration_no_delete BEFORE DELETE ON declarations
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS evidence_no_update BEFORE UPDATE ON evidence
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS evidence_no_delete BEFORE DELETE ON evidence
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS evaluation_no_update BEFORE UPDATE ON evaluations
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            CREATE TRIGGER IF NOT EXISTS evaluation_no_delete BEFORE DELETE ON evaluations
                BEGIN SELECT RAISE(ABORT, 'append_only'); END;
            """)

    @contextmanager
    def _connection(self):
        db = sqlite3.connect(self.database, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=10000")
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _get(db: sqlite3.Connection, query: str, params: tuple[Any, ...]) -> sqlite3.Row:
        row = db.execute(query, params).fetchone()
        if row is None:
            raise ContractError("Unknown entity, contract, declaration or evidence")
        return row

    def register_entity(self, entity_id: str, version: str, *, kind: str, declared_producer: str) -> None:
        entity_id = _text("entity_id", entity_id)
        version = _text("entity version", version, _VERSION)
        kind = _text("entity kind", kind)
        declared_producer = _text("declared producer", declared_producer)
        with self._connection() as db:
            previous = db.execute("SELECT kind, declared_producer FROM entities WHERE entity_id=? AND version=?", (entity_id, version)).fetchone()
            if previous:
                if (previous["kind"], previous["declared_producer"]) != (kind, declared_producer):
                    raise ContractError("Entity version is immutable")
                return
            db.execute("INSERT INTO entities VALUES (?,?,?,?,?)", (entity_id, version, kind, declared_producer, _utc()))

    def register_contract(self, capability_id: str, version: str, *, requirement: str, check_type: str = "bytes_equal") -> None:
        capability_id = _text("capability_id", capability_id)
        version = _text("contract version", version, _VERSION)
        if check_type != "bytes_equal":
            raise ContractError("Only data-only bytes_equal profile is implemented")
        if not isinstance(requirement, str) or not requirement.strip() or len(requirement) > 500:
            raise ContractError("Non-empty bounded requirement required")
        requirement = requirement.strip()
        with self._connection() as db:
            previous = db.execute("SELECT requirement,check_type FROM contracts WHERE capability_id=? AND version=?", (capability_id, version)).fetchone()
            if previous:
                if (previous["requirement"], previous["check_type"]) != (requirement, check_type):
                    raise ContractError("Contract version is immutable")
                return
            db.execute("INSERT INTO contracts VALUES (?,?,?,?)", (capability_id, version, check_type, requirement))

    def declare_capability(self, entity_id: str, version: str, capability_id: str, contract_version: str) -> None:
        entity_id = _text("entity_id", entity_id)
        version = _text("entity version", version, _VERSION)
        capability_id = _text("capability_id", capability_id)
        contract_version = _text("contract version", contract_version, _VERSION)
        with self._connection() as db:
            self._get(db, "SELECT 1 FROM entities WHERE entity_id=? AND version=?", (entity_id, version))
            self._get(db, "SELECT 1 FROM contracts WHERE capability_id=? AND version=?", (capability_id, contract_version))
            existing = db.execute("SELECT contract_version FROM declarations WHERE entity_id=? AND entity_version=? AND capability_id=?", (entity_id, version, capability_id)).fetchone()
            if existing:
                if existing["contract_version"] != contract_version:
                    raise ContractError("Declared capability is immutable in this entity version")
                return
            db.execute("INSERT INTO declarations VALUES (?,?,?,?)", (entity_id, version, capability_id, contract_version))

    def _store_bytes(self, data: bytes) -> str:
        if not isinstance(data, bytes) or len(data) > _MAX_ARTIFACT_BYTES:
            raise ContractError("Artifact must be bytes and <= 1 MiB")
        digest = _sha(data)
        subdir = self.cas / digest[:2]
        subdir.mkdir(exist_ok=True)
        if subdir.is_symlink() or not subdir.is_dir():
            raise IntegrityError("CAS directory is not a regular directory")
        dest = subdir / digest
        # Never follow a symlink in this CAS namespace.
        if dest.is_symlink():
            raise IntegrityError("CAS path is a symbolic link")
        try:
            fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            if self._read_bytes(digest) != data:
                raise IntegrityError("CAS collision or existing artifact corrupted")
            return digest
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
        except BaseException:
            dest.unlink(missing_ok=True)
            raise
        return digest

    def _read_bytes(self, digest: str) -> bytes:
        if not _HASH.fullmatch(digest):
            raise ContractError("Invalid digest")
        path = self.cas / digest[:2] / digest
        if path.parent.is_symlink() or path.is_symlink() or not path.is_file() or path.stat().st_size > _MAX_ARTIFACT_BYTES:
            raise IntegrityError("CAS artifact unavailable or unsafe")
        data = path.read_bytes()
        if _sha(data) != digest:
            raise IntegrityError("CAS artifact digest mismatch")
        return data

    def receive_samples(
        self, entity_id: str, version: str, capability_id: str,
        *, source: bytes, output: bytes, producer_claim: str,
    ) -> str:
        """Keep submitted samples. No statement about how the output was generated."""
        entity_id = _text("entity_id", entity_id)
        version = _text("entity version", version, _VERSION)
        capability_id = _text("capability_id", capability_id)
        if producer_claim not in {"PASS", "FAIL", "UNKNOWN"}:
            raise ContractError("Invalid producer claim")
        with self._connection() as db:
            declared = self._get(db,
                "SELECT contract_version FROM declarations WHERE entity_id=? AND entity_version=? AND capability_id=?",
                (entity_id, version, capability_id))
            contract_version = declared["contract_version"]
        source_digest = self._store_bytes(source)
        output_digest = self._store_bytes(output)
        evidence_id = "EV-" + uuid.uuid4().hex
        with self._connection() as db:
            db.execute("INSERT INTO evidence VALUES (?,?,?,?,?,?,?,?,?)",
                (evidence_id, entity_id, version, capability_id, contract_version,
                 source_digest, output_digest, producer_claim, _utc()))
        return evidence_id

    def verify_samples(self, evidence_id: str) -> dict[str, Any]:
        """Deterministic check of supplied bytes; append result including failures."""
        with self._connection() as db:
            ev = self._get(db, "SELECT * FROM evidence WHERE evidence_id=?", (evidence_id,))
            contract = self._get(db, "SELECT * FROM contracts WHERE capability_id=? AND version=?",
                (ev["capability_id"], ev["contract_version"]))
        diagnostics: list[str] = []
        integrity = "PASS"
        sample_check = "UNKNOWN"
        try:
            source = self._read_bytes(ev["source_digest"])
            output = self._read_bytes(ev["output_digest"])
            if contract["check_type"] == "bytes_equal":
                sample_check = "PASS" if source == output else "FAIL"
            else:
                sample_check = "ERROR"
                diagnostics.append("Unknown verifier profile")
        except IntegrityError as exc:
            integrity = "FAIL"
            sample_check = "ERROR"
            diagnostics.append(str(exc))
        result = {
            "evaluation_id": "EVAL-" + uuid.uuid4().hex,
            "evidence_id": evidence_id,
            "verifier_id": "adl.bytes_equal",
            "verifier_version": "0.1.0",
            "integrity": integrity,
            "sample_check": sample_check,
            "behavior_execution": "NOT_RUN",
            "producer_authentication": "NOT_VERIFIED",
            "diagnostics": diagnostics,
        }
        with self._connection() as db:
            db.execute("INSERT INTO evaluations VALUES (?,?,?,?,?,?,?,?,?,?)",
                (result["evaluation_id"], evidence_id, result["verifier_id"],
                 result["verifier_version"], sample_check, integrity,
                 "NOT_RUN", "NOT_VERIFIED", _utc(), json.dumps(diagnostics, ensure_ascii=False)))
        return result

    def latest_result(self, entity_id: str, version: str, capability_id: str) -> str:
        with self._connection() as db:
            self._get(db,
                "SELECT 1 FROM declarations WHERE entity_id=? AND entity_version=? AND capability_id=?",
                (entity_id, version, capability_id))
            row = db.execute("""
                SELECT v.sample_check, v.integrity, e.source_digest, e.output_digest
                FROM evaluations v JOIN evidence e ON e.evidence_id=v.evidence_id
                WHERE e.entity_id=? AND e.entity_version=? AND e.capability_id=?
                ORDER BY v.rowid DESC LIMIT 1
            """, (entity_id, version, capability_id)).fetchone()
        if row is None or row["integrity"] != "PASS":
            return "UNKNOWN"
        try:
            self._read_bytes(row["source_digest"])
            self._read_bytes(row["output_digest"])
        except IntegrityError:
            return "UNKNOWN"  # stale PASS is never trusted after byte corruption
        return row["sample_check"]

    def compare_versions(self, entity_id: str, baseline: str, candidate: str) -> dict[str, Any]:
        """Compare sample checks only, NEVER assert demonstrated runtime behavior."""
        entity_id = _text("entity_id", entity_id)
        baseline = _text("baseline", baseline, _VERSION)
        candidate = _text("candidate", candidate, _VERSION)
        with self._connection() as db:
            for v in (baseline, candidate):
                self._get(db, "SELECT 1 FROM entities WHERE entity_id=? AND version=?", (entity_id, v))
            decls = {}
            for v in (baseline, candidate):
                decls[v] = {x["capability_id"]: x["contract_version"] for x in
                            db.execute("SELECT capability_id,contract_version FROM declarations WHERE entity_id=? AND entity_version=?", (entity_id, v))}
        base_caps = decls[baseline]
        next_caps = decls[candidate]
        removed = sorted(set(base_caps) - set(next_caps))
        added = sorted(set(next_caps) - set(base_caps))
        preserved: list[str] = []
        regressed: list[str] = []
        unverified: list[str] = []
        contract_changed: list[str] = []
        for capability in sorted(set(base_caps) & set(next_caps)):
            if base_caps[capability] != next_caps[capability]:
                contract_changed.append(capability)
                continue
            previous = self.latest_result(entity_id, baseline, capability)
            new = self.latest_result(entity_id, candidate, capability)
            if previous == "PASS" and new == "FAIL":
                regressed.append(capability)
            elif previous == "PASS" and new == "PASS":
                preserved.append(capability)
            else:
                unverified.append(capability)
        blockers = sorted(set(removed + regressed + unverified + contract_changed))
        return {
            "entity_id": entity_id, "baseline": baseline, "candidate": candidate,
            "added": added, "removed": removed, "preserved_sample_checks": preserved,
            "regressed_sample_checks": regressed, "unverified": unverified,
            "contract_changed": contract_changed,
            "sample_compatibility": "BLOCKED" if blockers else "PASS",
            "behavioral_compatibility": "NOT_VERIFIED",
            "promotion": "BLOCKED",  # no executable behavioral assessment in this slice
            "blockers": blockers if blockers else ["behavior_not_executed"],
        }
