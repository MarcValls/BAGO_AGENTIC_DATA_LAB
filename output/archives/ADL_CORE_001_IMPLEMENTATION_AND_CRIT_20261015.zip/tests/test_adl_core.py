"""ADL-CORE-001 contract conformance: positive and negative vectors (offline)."""
from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from adl_core import ADLCore, ContractError, IntegrityError


@pytest.fixture
def core(tmp_path):
    return ADLCore(tmp_path / "store")


def setup_pair(core):
    core.register_contract("file_preservation", "1.0", requirement="Submitted source and output bytes must match")
    for v in ("1.0", "1.1"):
        core.register_entity("FileManager", v, kind="library", declared_producer="untrusted-vendor")
        core.declare_capability("FileManager", v, "file_preservation", "1.0")


def test_cv01_positive_create_and_idempotent(core):
    setup_pair(core)
    core.register_entity("FileManager", "1.0", kind="library", declared_producer="untrusted-vendor")
    core.register_contract("file_preservation", "1.0", requirement="Submitted source and output bytes must match")
    core.declare_capability("FileManager", "1.0", "file_preservation", "1.0")


def test_cv02_negative_entity_version_cannot_mutate(core):
    setup_pair(core)
    with pytest.raises(ContractError, match="immutable"):
        core.register_entity("FileManager", "1.0", kind="agent", declared_producer="untrusted-vendor")


def test_cv03_negative_contract_cannot_mutate(core):
    setup_pair(core)
    with pytest.raises(ContractError, match="immutable"):
        core.register_contract("file_preservation", "1.0", requirement="redefined")


def test_cv04_positive_bytes_equal_but_unverified_behavior(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"exact bytes\x00", output=b"exact bytes\x00", producer_claim="FAIL")
    result = core.verify_samples(eid)
    assert result["sample_check"] == result["integrity"] == "PASS"
    assert result["behavior_execution"] == "NOT_RUN"
    assert result["producer_authentication"] == "NOT_VERIFIED"
    with sqlite3.connect(core.database) as db:
        assert db.execute("SELECT producer_claim FROM evidence WHERE evidence_id=?", (eid,)).fetchone()[0] == "FAIL"


def test_cv05_negative_false_producer_success_is_rejected(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.1", "file_preservation", source=b"ABC", output=b"AB", producer_claim="PASS")
    result = core.verify_samples(eid)
    assert result["sample_check"] == "FAIL"
    assert result["integrity"] == "PASS"
    assert result["behavior_execution"] == "NOT_RUN"


def test_cv06_negative_unknown_declaration_fails_closed(core):
    core.register_entity("FileManager", "1.0", kind="library", declared_producer="untrusted-vendor")
    with pytest.raises(ContractError, match="Unknown"):
        core.receive_samples("FileManager", "1.0", "file_preservation", source=b"x", output=b"x", producer_claim="PASS")


def test_cv07_negative_limit_and_claim_validation(core):
    setup_pair(core)
    with pytest.raises(ContractError, match="1 MiB"):
        core.receive_samples("FileManager", "1.0", "file_preservation", source=b"a" * (1024 * 1024 + 1), output=b"a", producer_claim="PASS")
    with pytest.raises(ContractError, match="claim"):
        core.receive_samples("FileManager", "1.0", "file_preservation", source=b"a", output=b"a", producer_claim="CERTIFIED")


def test_cv08_negative_corrupt_cas_keeps_history_and_fails(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"first", output=b"first", producer_claim="PASS")
    first = core.verify_samples(eid)
    assert first["sample_check"] == "PASS"
    with sqlite3.connect(core.database) as db:
        digest = db.execute("SELECT source_digest FROM evidence WHERE evidence_id=?", (eid,)).fetchone()[0]
    (core.cas / digest[:2] / digest).write_bytes(b"tampered")
    assert core.latest_result("FileManager", "1.0", "file_preservation") == "UNKNOWN"
    second = core.verify_samples(eid)
    assert second["integrity"] == "FAIL"
    assert second["sample_check"] == "ERROR"
    with sqlite3.connect(core.database) as db:
        assert db.execute("SELECT count(*) FROM evaluations WHERE evidence_id=?", (eid,)).fetchone()[0] == 2
    assert first["evaluation_id"] != second["evaluation_id"]


def test_cv09_negative_refuse_poisoned_existing_hash(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"clean", output=b"clean", producer_claim="PASS")
    with sqlite3.connect(core.database) as db:
        digest = db.execute("SELECT source_digest FROM evidence WHERE evidence_id=?", (eid,)).fetchone()[0]
    (core.cas / digest[:2] / digest).write_bytes(b"bad")
    with pytest.raises(IntegrityError):
        core.receive_samples("FileManager", "1.1", "file_preservation", source=b"clean", output=b"clean", producer_claim="PASS")


def test_cv10_positive_compare_preserved_sample_checks_but_no_promotion(core):
    setup_pair(core)
    for ver in ("1.0", "1.1"):
        evid = core.receive_samples("FileManager", ver, "file_preservation", source=b"a", output=b"a", producer_claim="PASS")
        core.verify_samples(evid)
    report = core.compare_versions("FileManager", "1.0", "1.1")
    assert report["preserved_sample_checks"] == ["file_preservation"]
    assert report["sample_compatibility"] == "PASS"
    assert report["promotion"] == "BLOCKED"
    assert report["behavioral_compatibility"] == "NOT_VERIFIED"


def test_cv11_negative_regression_detected(core):
    setup_pair(core)
    base = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"same", output=b"same", producer_claim="PASS")
    nxt = core.receive_samples("FileManager", "1.1", "file_preservation", source=b"same", output=b"lost", producer_claim="PASS")
    core.verify_samples(base)
    core.verify_samples(nxt)
    report = core.compare_versions("FileManager", "1.0", "1.1")
    assert report["regressed_sample_checks"] == ["file_preservation"]
    assert report["sample_compatibility"] == report["promotion"] == "BLOCKED"


def test_cv12_negative_unverified_candidate_blocks(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"a", output=b"a", producer_claim="PASS")
    core.verify_samples(eid)
    report = core.compare_versions("FileManager", "1.0", "1.1")
    assert report["unverified"] == ["file_preservation"]
    assert report["sample_compatibility"] == "BLOCKED"


def test_cv13_negative_contract_change_blocks(core):
    setup_pair(core)
    core.register_contract("file_preservation", "2.0", requirement="Changed meaning: can never silently substitute")
    core.register_entity("FileManager", "2.0", kind="library", declared_producer="untrusted-vendor")
    core.declare_capability("FileManager", "2.0", "file_preservation", "2.0")
    result = core.compare_versions("FileManager", "1.0", "2.0")
    assert result["contract_changed"] == ["file_preservation"]
    assert result["promotion"] == "BLOCKED"


def test_cv14_negative_disappearing_capability_blocks(core):
    setup_pair(core)
    core.register_entity("FileManager", "2.0", kind="library", declared_producer="untrusted-vendor")
    result = core.compare_versions("FileManager", "1.0", "2.0")
    assert result["removed"] == ["file_preservation"]
    assert result["promotion"] == "BLOCKED"


def test_cv15_positive_added_capability_is_not_promotion(core):
    setup_pair(core)
    core.register_contract("new_feature", "1.0", requirement="New feature has not been verified")
    core.declare_capability("FileManager", "1.1", "new_feature", "1.0")
    result = core.compare_versions("FileManager", "1.0", "1.1")
    assert result["added"] == ["new_feature"]
    assert result["promotion"] == "BLOCKED"


def test_cv16_negative_symlink_cas_is_rejected(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"good", output=b"good", producer_claim="PASS")
    with sqlite3.connect(core.database) as db:
        digest = db.execute("SELECT source_digest FROM evidence WHERE evidence_id=?", (eid,)).fetchone()[0]
    path = core.cas / digest[:2] / digest
    path.unlink()
    try:
        path.symlink_to(core.database)
    except (OSError, NotImplementedError):
        pytest.skip("Filesystem does not allow symlink creation")
    assert core.verify_samples(eid)["integrity"] == "FAIL"


def test_cv17_negative_invalid_identity_and_profile(core):
    with pytest.raises(ContractError):
        core.register_entity("../../unsafe", "1.0", kind="library", declared_producer="someone")
    with pytest.raises(ContractError):
        core.register_contract("foo", "1.0", requirement="content", check_type="execute_python")


def test_cv18_positive_cross_entity_isolation(core):
    setup_pair(core)
    core.register_entity("OtherLibrary", "1.0", kind="library", declared_producer="other")
    core.declare_capability("OtherLibrary", "1.0", "file_preservation", "1.0")
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"same", output=b"same", producer_claim="PASS")
    core.verify_samples(eid)
    assert core.latest_result("OtherLibrary", "1.0", "file_preservation") == "UNKNOWN"


def test_cv19_negative_untrusted_source_is_not_executed(core, tmp_path):
    setup_pair(core)
    marker = tmp_path / "pwned"
    untrusted_python = f"from pathlib import Path; Path({str(marker)!r}).write_text('WRONG')".encode()
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=untrusted_python, output=untrusted_python, producer_claim="PASS")
    assert core.verify_samples(eid)["sample_check"] == "PASS"
    assert not marker.exists()


def test_cv20_negative_sqlite_history_mutation_blocked(core):
    setup_pair(core)
    eid = core.receive_samples("FileManager", "1.0", "file_preservation", source=b"s", output=b"s", producer_claim="PASS")
    core.verify_samples(eid)
    with sqlite3.connect(core.database) as db:
        with pytest.raises(sqlite3.IntegrityError, match="append_only"):
            db.execute("UPDATE evidence SET producer_claim='FAIL' WHERE evidence_id=?", (eid,))
        with pytest.raises(sqlite3.IntegrityError, match="append_only"):
            db.execute("DELETE FROM evaluations WHERE evidence_id=?", (eid,))
